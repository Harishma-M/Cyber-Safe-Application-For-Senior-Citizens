"use client"

import {
  Home,
  BookOpen,
  HelpCircle,
  Shield,
  Bell,
  Phone,
  Settings,
  TrendingUp,
  Users,
  MessageSquare,
  Volume2,
  User,
} from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import Link from "next/link"
import { useState, useEffect } from "react"

const mainMenuItems = [
  {
    title: "Home",
    url: "/",
    icon: Home,
  },
  {
    title: "Learn Cyber Safety",
    url: "/learn",
    icon: BookOpen,
  },
  {
    title: "Practice Quiz",
    url: "/quiz",
    icon: HelpCircle,
  },
  {
    title: "Emergency Help",
    url: "/emergency",
    icon: Phone,
  },
  {
    title: "Scam Alerts",
    url: "/alerts",
    icon: Bell,
  },
  {
    title: "Message Checker",
    url: "/checker",
    icon: MessageSquare,
  },
]

const otherItems = [
  {
    title: "My Profile",
    url: "/profile",
    icon: User,
  },
  {
    title: "My Progress",
    url: "/progress",
    icon: TrendingUp,
  },
  {
    title: "Family Mode",
    url: "/family",
    icon: Users,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
]

export function AppSidebar() {
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(false)
  const [userData, setUserData] = useState<any>(null)

  useEffect(() => {
    const storedUserData = localStorage.getItem("userData")
    if (storedUserData) {
      setUserData(JSON.parse(storedUserData))
    }
  }, [])

  const handleVoiceToggle = () => {
    setIsVoiceEnabled(!isVoiceEnabled)
    if (!isVoiceEnabled) {
      const utterance = new SpeechSynthesisUtterance("Voice assistance enabled")
      speechSynthesis.speak(utterance)
    }
  }

  const getInitials = (name: string) => {
    return (
      name
        ?.split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase() || "U"
    )
  }

  return (
    <Sidebar className="border-r-2 border-blue-200 bg-gradient-to-b from-white to-blue-50">
      <SidebarHeader className="p-6 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        {/* Header background animation */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 via-purple-600/90 to-indigo-600/90"></div>
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/10 to-transparent animate-pulse"></div>
        </div>

        <div className="relative z-10 flex items-center gap-4">
          <div className="bg-white/20 backdrop-blur-sm p-3 rounded-2xl shadow-lg border border-white/30">
            <Shield className="h-10 w-10 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">CyberSafe</h1>
            <p className="text-blue-100 text-sm">Stay Safe Online</p>
          </div>
        </div>

        {/* User Info */}
        {userData && (
          <div className="relative z-10 mt-4 flex items-center gap-3 p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
            <Avatar className="h-10 w-10 border-2 border-white/50">
              <AvatarFallback className="text-sm font-bold bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                {getInitials(userData.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium text-sm truncate">{userData.name?.split(" ")[0] || "User"}</p>
              <p className="text-blue-100 text-xs truncate">{userData.location}</p>
            </div>
          </div>
        )}
      </SidebarHeader>

      <SidebarContent className="p-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            Main Menu
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {mainMenuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild size="lg" className="h-16 text-base font-medium group">
                    <Link
                      href={item.url}
                      className="flex items-center gap-4 p-4 rounded-xl hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 transition-all duration-300 hover:shadow-lg border-2 border-transparent hover:border-blue-200"
                    >
                      <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-2 rounded-lg group-hover:scale-110 transition-transform duration-300">
                        <item.icon className="h-5 w-5 text-white" />
                      </div>
                      <span className="text-gray-700 group-hover:text-blue-700 transition-colors">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-8">
          <SidebarGroupLabel className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
            More Options
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {otherItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild size="lg" className="h-16 text-base font-medium group">
                    <Link
                      href={item.url}
                      className="flex items-center gap-4 p-4 rounded-xl hover:bg-gradient-to-r hover:from-purple-50 hover:to-pink-50 transition-all duration-300 hover:shadow-lg border-2 border-transparent hover:border-purple-200"
                    >
                      <div className="bg-gradient-to-br from-purple-500 to-pink-600 p-2 rounded-lg group-hover:scale-110 transition-transform duration-300">
                        <item.icon className="h-5 w-5 text-white" />
                      </div>
                      <span className="text-gray-700 group-hover:text-purple-700 transition-colors">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
        <Button
          onClick={handleVoiceToggle}
          variant={isVoiceEnabled ? "default" : "outline"}
          className={`w-full h-14 text-base font-medium transition-all duration-300 ${
            isVoiceEnabled
              ? "bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 shadow-lg"
              : "border-2 border-blue-200 hover:bg-blue-100 hover:border-blue-400"
          }`}
        >
          <Volume2 className="h-5 w-5 mr-2" />
          {isVoiceEnabled ? "Voice On" : "Voice Off"}
        </Button>
      </SidebarFooter>
    </Sidebar>
  )
}
