"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  User,
  Mail,
  Phone,
  MapPin,
  Globe,
  Calendar,
  Shield,
  Edit,
  Settings,
  Award,
  TrendingUp,
  Star,
} from "lucide-react"
import { useState, useEffect } from "react"

interface UserData {
  name: string
  email: string
  phone: string
  location: string
  language: string
  emergencyContact: string
  emergencyName: string
  joinDate: string
}

export function UserProfile() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [stats, setStats] = useState({
    coursesCompleted: 4,
    totalCourses: 8,
    averageScore: 88,
    badges: 3,
    streak: 7,
  })

  useEffect(() => {
    const storedUserData = localStorage.getItem("userData")
    if (storedUserData) {
      setUserData(JSON.parse(storedUserData))
    }
  }, [])

  if (!userData) {
    return null
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  const achievements = [
    { name: "First Steps", icon: Star, earned: true, description: "Completed first lesson" },
    { name: "Quiz Master", icon: Award, earned: true, description: "Scored 90%+ on quiz" },
    { name: "Safety Expert", icon: Shield, earned: true, description: "Completed 3 courses" },
    { name: "Streak Champion", icon: TrendingUp, earned: false, description: "7-day learning streak" },
  ]

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 shadow-xl">
        <CardHeader className="pb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <Avatar className="h-20 w-20 border-4 border-white shadow-lg">
                <AvatarFallback className="text-2xl font-bold bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                  {getInitials(userData.name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-3xl font-bold text-gray-800">{userData.name}</h2>
                <p className="text-gray-600 text-lg">Cyber Safety Learner</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className="bg-green-500">Active</Badge>
                  <Badge variant="outline">Member since {new Date(userData.joinDate).getFullYear()}</Badge>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="lg">
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
              <Button variant="outline" size="lg">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card className="border-2 border-green-200 bg-green-50">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-green-600">{stats.coursesCompleted}</div>
            <div className="text-gray-600">Courses Completed</div>
          </CardContent>
        </Card>
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-blue-600">{stats.averageScore}%</div>
            <div className="text-gray-600">Average Score</div>
          </CardContent>
        </Card>
        <Card className="border-2 border-purple-200 bg-purple-50">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-purple-600">{stats.badges}</div>
            <div className="text-gray-600">Badges Earned</div>
          </CardContent>
        </Card>
        <Card className="border-2 border-orange-200 bg-orange-50">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-orange-600">{stats.streak}</div>
            <div className="text-gray-600">Day Streak</div>
          </CardContent>
        </Card>
        <Card className="border-2 border-indigo-200 bg-indigo-50">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-indigo-600">
              {Math.round((stats.coursesCompleted / stats.totalCourses) * 100)}%
            </div>
            <div className="text-gray-600">Progress</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Personal Information */}
        <Card className="border-2 border-gray-200 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-blue-600" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Mail className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Email</p>
                <p className="text-gray-600">{userData.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Phone className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Phone</p>
                <p className="text-gray-600">{userData.phone}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <MapPin className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Location</p>
                <p className="text-gray-600">{userData.location}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Globe className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Language</p>
                <p className="text-gray-600 capitalize">{userData.language}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Calendar className="h-5 w-5 text-gray-500" />
              <div>
                <p className="font-medium">Member Since</p>
                <p className="text-gray-600">{new Date(userData.joinDate).toLocaleDateString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Achievements */}
        <Card className="border-2 border-yellow-200 bg-yellow-50 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-yellow-600" />
              Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {achievements.map((achievement, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 text-center ${
                    achievement.earned ? "border-yellow-400 bg-yellow-100" : "border-gray-300 bg-gray-100 opacity-60"
                  }`}
                >
                  <div
                    className={`p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center ${
                      achievement.earned ? "bg-yellow-500" : "bg-gray-400"
                    }`}
                  >
                    <achievement.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-bold text-gray-800 text-sm">{achievement.name}</h3>
                  <p className="text-xs text-gray-600 mt-1">{achievement.description}</p>
                  {achievement.earned && <Badge className="mt-2 bg-yellow-500 text-xs">Earned!</Badge>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Emergency Contact */}
      {(userData.emergencyName || userData.emergencyContact) && (
        <Card className="border-2 border-red-200 bg-red-50 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-red-600" />
              Emergency Contact
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 p-4 bg-white rounded-lg">
              <div className="bg-red-500 p-3 rounded-full">
                <Phone className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="font-semibold text-gray-800">{userData.emergencyName}</p>
                <p className="text-gray-600">{userData.emergencyContact}</p>
              </div>
              <Button className="ml-auto bg-red-500 hover:bg-red-600">
                <Phone className="h-4 w-4 mr-2" />
                Call Now
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
