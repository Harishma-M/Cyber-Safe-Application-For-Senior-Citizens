import { CheckCircle, XCircle, Clock, Mail, Phone, Shield } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

interface VerificationStatusProps {
  emailVerified: boolean
  phoneVerified: boolean
  isVerified: boolean
  email?: string
  phone?: string
}

export function VerificationStatus({
  emailVerified,
  phoneVerified,
  isVerified,
  email,
  phone,
}: VerificationStatusProps) {
  const getStatusIcon = (verified: boolean) => {
    if (verified) {
      return <CheckCircle className="h-4 w-4 text-green-600" />
    }
    return <XCircle className="h-4 w-4 text-red-500" />
  }

  const getStatusBadge = (verified: boolean) => {
    if (verified) {
      return (
        <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
          Verified
        </Badge>
      )
    }
    return (
      <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200">
        Not Verified
      </Badge>
    )
  }

  const getOverallStatus = () => {
    if (isVerified && emailVerified && phoneVerified) {
      return (
        <div className="flex items-center gap-2 text-green-600">
          <Shield className="h-5 w-5" />
          <span className="font-semibold">Account Fully Verified</span>
        </div>
      )
    } else if (emailVerified || phoneVerified) {
      return (
        <div className="flex items-center gap-2 text-yellow-600">
          <Clock className="h-5 w-5" />
          <span className="font-semibold">Partial Verification</span>
        </div>
      )
    } else {
      return (
        <div className="flex items-center gap-2 text-red-600">
          <XCircle className="h-5 w-5" />
          <span className="font-semibold">Verification Required</span>
        </div>
      )
    }
  }

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="text-center">{getOverallStatus()}</div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Email Verification</p>
                  {email && <p className="text-sm text-gray-600">{email}</p>}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusIcon(emailVerified)}
                {getStatusBadge(emailVerified)}
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Phone Verification</p>
                  {phone && <p className="text-sm text-gray-600">{phone}</p>}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusIcon(phoneVerified)}
                {getStatusBadge(phoneVerified)}
              </div>
            </div>
          </div>

          {!isVerified && (
            <div className="text-center p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                Complete verification to access all features and ensure account security.
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
