"use client"

export interface User {
  id: string
  name: string
  email: string
  phone: string
  address: string
  city: string
  state: string
  userType: "senior" | "family" | "caregiver"
  joinDate: string
  isVerified: boolean
  preferences?: {
    language: string
    fontSize: number
    voiceEnabled: boolean
    notifications: boolean
  }
  stats?: {
    coursesCompleted: number
    totalCourses: number
    averageScore: number
    badges: number
    streak: number
  }
}

export const getCurrentUser = (): User | null => {
  if (typeof window === "undefined") return null

  const userData = localStorage.getItem("currentUser")
  return userData ? JSON.parse(userData) : null
}

export const isAuthenticated = (): boolean => {
  if (typeof window === "undefined") return false

  return localStorage.getItem("isAuthenticated") === "true"
}

export const logout = () => {
  localStorage.removeItem("currentUser")
  localStorage.removeItem("isAuthenticated")
  window.location.href = "/auth"
}

export const updateUserData = (userData: Partial<User>) => {
  const currentUser = getCurrentUser()
  if (currentUser) {
    const updatedUser = { ...currentUser, ...userData }
    localStorage.setItem("currentUser", JSON.stringify(updatedUser))
    return updatedUser
  }
  return null
}

// Get user-specific dashboard configuration
export const getUserDashboardConfig = (userType: string) => {
  const configs = {
    senior: {
      primaryColor: "blue",
      features: ["learning", "quiz", "emergency", "checker"],
      fontSize: "large",
      simplifiedUI: true,
      voiceAssistance: true,
      emergencyAccess: true,
    },
    family: {
      primaryColor: "green",
      features: ["monitoring", "reports", "alerts", "learning"],
      fontSize: "medium",
      simplifiedUI: false,
      voiceAssistance: false,
      emergencyAccess: true,
      canViewSeniorProgress: true,
    },
    caregiver: {
      primaryColor: "purple",
      features: ["management", "reports", "training", "alerts"],
      fontSize: "medium",
      simplifiedUI: false,
      voiceAssistance: false,
      emergencyAccess: true,
      canManageMultipleUsers: true,
    },
  }

  return configs[userType as keyof typeof configs] || configs.senior
}
