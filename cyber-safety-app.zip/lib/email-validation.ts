export interface EmailValidationResult {
  isValid: boolean
  error?: string
  suggestion?: string
  riskLevel: "low" | "medium" | "high"
  provider?: string
}

export interface PhoneValidationResult {
  isValid: boolean
  error?: string
  formatted?: string
  carrier?: string
}

// Common email typos and their corrections
const emailTypos: Record<string, string> = {
  "gmial.com": "gmail.com",
  "gmai.com": "gmail.com",
  "gmail.co": "gmail.com",
  "yahooo.com": "yahoo.com",
  "yaho.com": "yahoo.com",
  "hotmial.com": "hotmail.com",
  "hotmai.com": "hotmail.com",
  "outlok.com": "outlook.com",
  "outloo.com": "outlook.com",
}

// Trusted email providers
const trustedProviders = [
  "gmail.com",
  "yahoo.com",
  "yahoo.co.in",
  "hotmail.com",
  "outlook.com",
  "rediffmail.com",
  "indiatimes.com",
  "sify.com",
  "vsnl.com",
  "sancharnet.in",
]

// Suspicious patterns
const suspiciousPatterns = [
  /10minutemail/i,
  /tempmail/i,
  /guerrillamail/i,
  /mailinator/i,
  /throwaway/i,
  /temp-mail/i,
  /disposable/i,
]

export function validateEmailAdvanced(email: string): EmailValidationResult {
  if (!email) {
    return {
      isValid: false,
      error: "Email is required",
      riskLevel: "high",
    }
  }

  // Basic format validation
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
  if (!emailRegex.test(email)) {
    return {
      isValid: false,
      error: "Please enter a valid email address format",
      riskLevel: "high",
    }
  }

  const [localPart, domain] = email.toLowerCase().split("@")

  // Check for suspicious patterns
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(domain)) {
      return {
        isValid: false,
        error: "Temporary or disposable email addresses are not allowed",
        riskLevel: "high",
      }
    }
  }

  // Check for common typos
  if (emailTypos[domain]) {
    return {
      isValid: false,
      error: "Email domain appears to have a typo",
      suggestion: `Did you mean ${localPart}@${emailTypos[domain]}?`,
      riskLevel: "medium",
    }
  }

  // Check for suspicious patterns in email
  if (email.includes("..") || email.startsWith(".") || email.endsWith(".")) {
    return {
      isValid: false,
      error: "Email format contains invalid characters",
      riskLevel: "high",
    }
  }

  // Determine provider and risk level
  let riskLevel: "low" | "medium" | "high" = "low"
  let provider = domain

  if (trustedProviders.includes(domain)) {
    riskLevel = "low"
    provider = domain
  } else if (domain.includes(".")) {
    // Custom domain - medium risk
    riskLevel = "medium"
  } else {
    // Invalid domain format
    return {
      isValid: false,
      error: "Please use a valid email provider",
      riskLevel: "high",
    }
  }

  return {
    isValid: true,
    riskLevel,
    provider,
  }
}

export function validatePhoneAdvanced(phone: string): PhoneValidationResult {
  if (!phone) {
    return {
      isValid: false,
      error: "Phone number is required",
    }
  }

  // Clean the phone number
  const cleanPhone = phone.replace(/\s+/g, "").replace(/[()-]/g, "")

  // Indian mobile number validation
  const phoneRegex = /^(\+91|91)?([6-9]\d{9})$/
  const match = cleanPhone.match(phoneRegex)

  if (!match) {
    return {
      isValid: false,
      error: "Please enter a valid Indian mobile number (10 digits starting with 6-9)",
    }
  }

  const mobileNumber = match[2]
  const formatted = `+91 ${mobileNumber.slice(0, 5)} ${mobileNumber.slice(5)}`

  // Determine carrier based on number prefix
  let carrier = "Unknown"
  const prefix = mobileNumber.slice(0, 4)

  if (["9876", "9877", "9878", "9879"].includes(prefix)) {
    carrier = "Airtel"
  } else if (["9988", "9989", "9990", "9991"].includes(prefix)) {
    carrier = "Vodafone"
  } else if (["9999", "8888", "7777"].includes(prefix)) {
    carrier = "Jio"
  } else if (["9444", "9445", "9446"].includes(prefix)) {
    carrier = "BSNL"
  }

  return {
    isValid: true,
    formatted,
    carrier,
  }
}

// Mock email existence check (in real app, this would be an API call)
export async function checkEmailExists(email: string): Promise<boolean> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Mock some existing emails for demo
  const existingEmails = ["test@gmail.com", "demo@yahoo.com", "sample@hotmail.com"]

  return existingEmails.includes(email.toLowerCase())
}
