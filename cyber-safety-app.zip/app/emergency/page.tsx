"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Phone, MapPin, AlertTriangle, Shield, Users, FileText, ExternalLink, Volume2 } from "lucide-react"
import { useState } from "react"

export default function EmergencyPage() {
  const [isEmergencyMode, setIsEmergencyMode] = useState(false)

  const emergencyContacts = [
    {
      name: "Cybercrime Helpline",
      number: "1930",
      description: "National cybercrime reporting helpline",
      type: "primary",
    },
    {
      name: "Police Emergency",
      number: "100",
      description: "General police emergency number",
      type: "secondary",
    },
    {
      name: "Women Helpline",
      number: "1091",
      description: "For women in distress",
      type: "secondary",
    },
  ]

  const familyContacts = [
    { name: "Ravi (Son)", number: "+91 98765 43210" },
    { name: "Priya (Daughter)", number: "+91 87654 32109" },
    { name: "Neighbor - Sharma Uncle", number: "+91 76543 21098" },
  ]

  const handleEmergencyCall = (number: string) => {
    // In a real app, this would initiate a phone call
    window.location.href = `tel:${number}`
  }

  const handleSendAlert = () => {
    setIsEmergencyMode(true)
    // In a real app, this would send alerts to family members
    setTimeout(() => setIsEmergencyMode(false), 3000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="bg-red-500 p-4 rounded-full">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800">Emergency Help</h1>
          </div>
          <p className="text-xl text-gray-600">Get immediate help when you encounter cyber threats or scams</p>
        </div>

        {/* Emergency Alert */}
        {isEmergencyMode && (
          <Alert className="border-red-500 bg-red-50">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-lg font-medium">
              Emergency alert sent to your family members! Help is on the way.
            </AlertDescription>
          </Alert>
        )}

        {/* Quick Emergency Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="border-2 border-red-300 bg-red-50">
            <CardHeader>
              <CardTitle className="text-xl text-red-800 flex items-center gap-2">
                <AlertTriangle className="h-6 w-6" />
                I'm Being Scammed Right Now!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">If someone is trying to scam you right now, take immediate action:</p>
              <div className="space-y-3">
                <Button
                  onClick={() => handleEmergencyCall("1930")}
                  className="w-full h-14 text-lg font-bold bg-red-600 hover:bg-red-700"
                >
                  <Phone className="h-6 w-6 mr-3" />
                  Call Cybercrime Helpline (1930)
                </Button>
                <Button
                  onClick={handleSendAlert}
                  variant="outline"
                  className="w-full h-12 text-base border-red-300 text-red-700 hover:bg-red-100 bg-transparent"
                >
                  <Users className="h-5 w-5 mr-2" />
                  Alert My Family
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-blue-300 bg-blue-50">
            <CardHeader>
              <CardTitle className="text-xl text-blue-800 flex items-center gap-2">
                <MapPin className="h-6 w-6" />
                Find Nearest Police Station
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700">Locate the nearest police station for in-person reporting:</p>
              <Button className="w-full h-12 text-base bg-blue-600 hover:bg-blue-700">
                <MapPin className="h-5 w-5 mr-2" />
                Open Maps & Find Station
              </Button>
              <div className="text-sm text-gray-600 space-y-1">
                <p>
                  <strong>Nearest Station:</strong> City Police Station
                </p>
                <p>
                  <strong>Distance:</strong> 2.3 km away
                </p>
                <p>
                  <strong>Phone:</strong> +91 80 2294 2222
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Emergency Contacts */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Phone className="h-6 w-6 text-green-600" />
              Emergency Contacts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {emergencyContacts.map((contact, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 ${
                    contact.type === "primary" ? "border-red-300 bg-red-50" : "border-gray-300 bg-gray-50"
                  }`}
                >
                  <h3 className="font-bold text-lg">{contact.name}</h3>
                  <p className="text-2xl font-bold text-blue-600 my-2">{contact.number}</p>
                  <p className="text-sm text-gray-600 mb-3">{contact.description}</p>
                  <Button
                    onClick={() => handleEmergencyCall(contact.number)}
                    className={`w-full ${
                      contact.type === "primary" ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"
                    }`}
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call Now
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Family Contacts */}
        <Card className="border-2 border-green-300">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-3">
              <Users className="h-6 w-6 text-green-600" />
              Trusted Family Contacts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {familyContacts.map((contact, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <p className="font-semibold text-gray-800">{contact.name}</p>
                    <p className="text-gray-600">{contact.number}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleEmergencyCall(contact.number)}
                      size="sm"
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Phone className="h-4 w-4 mr-1" />
                      Call
                    </Button>
                    <Button variant="outline" size="sm" className="border-green-300 text-green-700 bg-transparent">
                      Alert
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Report Scam */}
        <Card className="border-2 border-purple-300">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-3">
              <FileText className="h-6 w-6 text-purple-600" />
              Report a Scam
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-700">Report cybercrime incidents to help protect others and get assistance:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button className="h-12 text-base bg-purple-600 hover:bg-purple-700">
                <FileText className="h-5 w-5 mr-2" />
                Quick Report Form
              </Button>
              <Button
                variant="outline"
                className="h-12 text-base border-purple-300 text-purple-700 bg-transparent"
                onClick={() => window.open("https://cybercrime.gov.in", "_blank")}
              >
                <ExternalLink className="h-5 w-5 mr-2" />
                Official Portal
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Safety Instructions */}
        <Card className="border-2 border-yellow-300 bg-yellow-50">
          <CardHeader>
            <CardTitle className="text-xl">What to Do When Scammed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-bold text-gray-800">✋ Immediate Actions:</h4>
                <ul className="space-y-2 text-gray-700">
                  <li>• Stop all communication with the scammer</li>
                  <li>• Don't share any more information</li>
                  <li>• Take screenshots of messages/calls</li>
                  <li>• Note down phone numbers and details</li>
                </ul>
              </div>
              <div className="space-y-3">
                <h4 className="font-bold text-gray-800">📞 Next Steps:</h4>
                <ul className="space-y-2 text-gray-700">
                  <li>• Call cybercrime helpline (1930)</li>
                  <li>• Inform your bank if money involved</li>
                  <li>• File a police complaint</li>
                  <li>• Alert family and friends</li>
                </ul>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t">
              <Button variant="outline" className="w-full bg-transparent">
                <Volume2 className="h-4 w-4 mr-2" />
                Listen to Instructions
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
