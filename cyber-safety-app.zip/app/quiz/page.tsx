"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { HelpCircle, Trophy, Star, Play, Clock, CheckCircle, Target, Award } from "lucide-react"
import Link from "next/link"

const quizCategories = [
  {
    id: 1,
    title: "Phishing Scams Quiz",
    description: "Test your ability to spot fake emails and messages",
    questions: 10,
    duration: "5 min",
    difficulty: "Beginner",
    completed: true,
    score: 90,
    attempts: 3,
    color: "bg-red-500",
  },
  {
    id: 2,
    title: "Banking Safety Quiz",
    description: "Check your knowledge about OTP and banking frauds",
    questions: 12,
    duration: "6 min",
    difficulty: "Beginner",
    completed: true,
    score: 85,
    attempts: 2,
    color: "bg-blue-500",
  },
  {
    id: 3,
    title: "Password Security Quiz",
    description: "Evaluate your password creation and management skills",
    questions: 8,
    duration: "4 min",
    difficulty: "Beginner",
    completed: true,
    score: 95,
    attempts: 1,
    color: "bg-green-500",
  },
  {
    id: 4,
    title: "Fake Apps & Links Quiz",
    description: "Learn to identify dangerous apps and malicious links",
    questions: 15,
    duration: "8 min",
    difficulty: "Intermediate",
    completed: false,
    score: 0,
    attempts: 0,
    color: "bg-purple-500",
  },
  {
    id: 5,
    title: "Social Media Safety Quiz",
    description: "Test your knowledge about staying safe on social platforms",
    questions: 10,
    duration: "5 min",
    difficulty: "Intermediate",
    completed: false,
    score: 0,
    attempts: 0,
    color: "bg-orange-500",
  },
  {
    id: 6,
    title: "Online Shopping Quiz",
    description: "Check your understanding of safe online shopping practices",
    questions: 12,
    duration: "6 min",
    difficulty: "Advanced",
    completed: false,
    score: 0,
    attempts: 0,
    color: "bg-pink-500",
  },
]

export default function QuizPage() {
  const completedQuizzes = quizCategories.filter((quiz) => quiz.completed).length
  const totalQuizzes = quizCategories.length
  const averageScore =
    quizCategories.filter((quiz) => quiz.completed).reduce((sum, quiz) => sum + quiz.score, 0) / completedQuizzes || 0

  const achievements = [
    { name: "First Quiz", icon: Star, earned: true, description: "Complete your first quiz" },
    { name: "Perfect Score", icon: Trophy, earned: true, description: "Score 100% on any quiz" },
    { name: "Quick Learner", icon: Target, earned: true, description: "Complete 3 quizzes" },
    { name: "Safety Expert", icon: Award, earned: false, description: "Complete all quizzes" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="bg-purple-500 p-4 rounded-full">
              <HelpCircle className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800">Practice Quiz</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Test your cybersecurity knowledge with interactive quizzes and earn achievements
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardContent className="p-6 text-center">
              <div className="bg-blue-500 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-blue-600">{completedQuizzes}</p>
              <p className="text-gray-600">Quizzes Completed</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-200 bg-green-50">
            <CardContent className="p-6 text-center">
              <div className="bg-green-500 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <Trophy className="h-6 w-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-green-600">{averageScore.toFixed(0)}%</p>
              <p className="text-gray-600">Average Score</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-200 bg-purple-50">
            <CardContent className="p-6 text-center">
              <div className="bg-purple-500 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <Star className="h-6 w-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-purple-600">3</p>
              <p className="text-gray-600">Achievements</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-orange-200 bg-orange-50">
            <CardContent className="p-6 text-center">
              <div className="bg-orange-500 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                <Target className="h-6 w-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-orange-600">95%</p>
              <p className="text-gray-600">Best Score</p>
            </CardContent>
          </Card>
        </div>

        {/* Quiz Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizCategories.map((quiz) => (
            <Card
              key={quiz.id}
              className={`border-2 hover:shadow-lg transition-all duration-200 ${
                quiz.completed ? "border-green-300 bg-green-50" : "border-gray-200 hover:border-purple-300"
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className={`${quiz.color} p-3 rounded-full`}>
                    <HelpCircle className="h-6 w-6 text-white" />
                  </div>
                  {quiz.completed && (
                    <div className="flex items-center gap-1">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <Badge className="bg-green-500 text-white">{quiz.score}%</Badge>
                    </div>
                  )}
                </div>
                <CardTitle className="text-xl">{quiz.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">{quiz.description}</p>

                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <div className="flex items-center gap-1">
                    <HelpCircle className="h-4 w-4" />
                    {quiz.questions} questions
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {quiz.duration}
                  </div>
                </div>

                <Badge variant="outline" className="text-xs">
                  {quiz.difficulty}
                </Badge>

                {quiz.completed && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Best Score</span>
                      <span className="font-semibold">{quiz.score}%</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Attempts</span>
                      <span>{quiz.attempts}</span>
                    </div>
                  </div>
                )}

                <Link href={`/quiz/${quiz.id}`}>
                  <Button className="w-full h-12 text-base font-medium">
                    <Play className="h-4 w-4 mr-2" />
                    {quiz.completed ? "Retake Quiz" : "Start Quiz"}
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Achievements */}
        <Card className="border-2 border-yellow-300 bg-yellow-50">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Trophy className="h-6 w-6 text-yellow-600" />
              Your Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {achievements.map((achievement, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 text-center ${
                    achievement.earned ? "border-yellow-400 bg-yellow-100" : "border-gray-300 bg-gray-100 opacity-60"
                  }`}
                >
                  <div
                    className={`p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center ${
                      achievement.earned ? "bg-yellow-500" : "bg-gray-400"
                    }`}
                  >
                    <achievement.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-bold text-gray-800">{achievement.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">{achievement.description}</p>
                  {achievement.earned && <Badge className="mt-2 bg-yellow-500">Earned!</Badge>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quiz Tips */}
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-xl">Quiz Tips for Success</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-bold text-gray-800">📚 Before Starting:</h4>
                <ul className="space-y-2 text-gray-700">
                  <li>• Review the related learning module first</li>
                  <li>• Find a quiet place to concentrate</li>
                  <li>• Take your time - there's no rush</li>
                  <li>• Read each question carefully</li>
                </ul>
              </div>
              <div className="space-y-3">
                <h4 className="font-bold text-gray-800">🎯 During the Quiz:</h4>
                <ul className="space-y-2 text-gray-700">
                  <li>• Think about real-life examples</li>
                  <li>• Use the hint button if available</li>
                  <li>• Don't worry about perfect scores</li>
                  <li>• Learn from incorrect answers</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
