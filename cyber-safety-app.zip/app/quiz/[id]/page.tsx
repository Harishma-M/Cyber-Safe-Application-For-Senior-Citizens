"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  ArrowLeft,
  CheckCircle,
  XCircle,
  ArrowRight,
  Trophy,
  RotateCcw,
  Volume2,
  HelpCircle,
  AlertTriangle,
  Shield,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useParams } from "next/navigation"

const quizData = {
  1: {
    title: "Phishing Scams Quiz",
    description: "Test your knowledge about phishing and email safety",
    questions: [
      {
        id: 1,
        question: "What is phishing?",
        options: [
          "A type of fishing with a net",
          "When criminals try to steal your personal information by pretending to be someone you trust",
          "A computer virus that deletes files",
          "A way to make your internet faster",
        ],
        correct: 1,
        explanation:
          "Phishing is when criminals pretend to be trusted organizations to steal your personal information like passwords, bank details, or credit card numbers.",
      },
      {
        id: 2,
        question:
          "You receive an email saying 'Your bank account will be closed in 24 hours. Click here to verify.' What should you do?",
        options: [
          "Click the link immediately to save your account",
          "Forward the email to all your friends",
          "Delete the email and call your bank directly using the official number",
          "Reply to the email with your bank details",
        ],
        correct: 2,
        explanation:
          "This is a classic phishing attempt. Banks never ask you to verify accounts through email. Always contact your bank directly using official phone numbers.",
      },
      {
        id: 3,
        question: "Which of these is a sign of a phishing email?",
        options: [
          "It has perfect grammar and spelling",
          "It comes from your bank's official email address",
          "It creates urgency and asks you to 'act now'",
          "It includes your full name and account details",
        ],
        correct: 2,
        explanation:
          "Phishing emails often create false urgency to make you act quickly without thinking. Phrases like 'act now', 'urgent action required', or 'account will be closed' are red flags.",
      },
      {
        id: 4,
        question: "What should you do if you're not sure if an email is legitimate?",
        options: [
          "Click the link to check if it's real",
          "Ask your neighbor what they think",
          "Contact the organization directly using official contact information",
          "Share it on social media to get opinions",
        ],
        correct: 2,
        explanation:
          "When in doubt, always verify directly with the organization using official contact methods. Never click suspicious links or share potentially dangerous emails with others.",
      },
      {
        id: 5,
        question:
          "A website asks for your credit card details but doesn't have 'https://' in the address. What should you do?",
        options: [
          "Enter your details anyway - it's probably safe",
          "Never enter sensitive information on non-secure websites",
          "Ask the website owner to make it secure first",
          "Use a different credit card instead",
        ],
        correct: 1,
        explanation:
          "Never enter sensitive information on websites that don't have 'https://' (note the 's'). The 's' stands for secure and means your information is encrypted.",
      },
    ],
  },
  2: {
    title: "Banking & OTP Safety Quiz",
    description: "Test your knowledge about banking frauds and OTP security",
    questions: [
      {
        id: 1,
        question: "What does OTP stand for?",
        options: [
          "Online Transaction Password",
          "One-Time Password",
          "Official Transfer Pin",
          "Open Transaction Protocol",
        ],
        correct: 1,
        explanation:
          "OTP stands for One-Time Password. It's a unique code that can only be used once and expires quickly, making it more secure than regular passwords.",
      },
      {
        id: 2,
        question: "Someone calls claiming to be from your bank and asks for your OTP. What should you do?",
        options: [
          "Give them the OTP since they're from the bank",
          "Ask them to call back later",
          "Never share your OTP - banks never ask for it over phone",
          "Share only half of the OTP for security",
        ],
        correct: 2,
        explanation:
          "Banks will NEVER ask for your OTP over phone, email, or SMS. OTP is only for you to enter on official websites or apps. Anyone asking for OTP is a scammer.",
      },
      {
        id: 3,
        question: "You receive an SMS: 'Your account is blocked. Call 9876543210 to unblock.' What should you do?",
        options: [
          "Call the number immediately",
          "Ignore the message and check your account through official banking app",
          "Forward the message to your family",
          "Reply to the SMS with your account details",
        ],
        correct: 1,
        explanation:
          "This is a common scam. Banks don't block accounts suddenly or ask you to call random numbers. Always check your account through official banking apps or visit the branch.",
      },
      {
        id: 4,
        question: "What should you do if you lose network connectivity on your phone suddenly?",
        options: [
          "Wait for it to come back automatically",
          "Restart your phone and forget about it",
          "Immediately contact your mobile service provider",
          "Buy a new phone",
        ],
        correct: 2,
        explanation:
          "Sudden loss of network could indicate SIM swap fraud, where criminals get a duplicate of your SIM to receive your OTPs and banking messages. Contact your provider immediately.",
      },
      {
        id: 5,
        question: "Which of these is the safest way to do online banking?",
        options: [
          "Use public WiFi at cafes for better speed",
          "Save your banking password in the browser",
          "Use your home WiFi and official banking apps",
          "Share your login details with family for convenience",
        ],
        correct: 2,
        explanation:
          "Always use secure, private internet connections and official banking apps. Never use public WiFi for banking or share your login credentials with anyone.",
      },
    ],
  },
}

export default function QuizPage() {
  const params = useParams()
  const quizId = Number.parseInt(params.id as string)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [score, setScore] = useState(0)
  const [answers, setAnswers] = useState<number[]>([])
  const [quizCompleted, setQuizCompleted] = useState(false)

  const quiz = quizData[quizId as keyof typeof quizData]

  if (!quiz) {
    return <div>Quiz not found</div>
  }

  const question = quiz.questions[currentQuestion]
  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex)
  }

  const handleNext = () => {
    if (selectedAnswer === null) return

    const newAnswers = [...answers]
    newAnswers[currentQuestion] = selectedAnswer

    if (selectedAnswer === question.correct) {
      setScore(score + 1)
    }

    setAnswers(newAnswers)
    setShowResult(true)

    setTimeout(() => {
      if (currentQuestion < quiz.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1)
        setSelectedAnswer(null)
        setShowResult(false)
      } else {
        setQuizCompleted(true)
      }
    }, 3000)
  }

  const handleRestart = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setScore(0)
    setAnswers([])
    setQuizCompleted(false)
  }

  const speakQuestion = () => {
    const text = `Question ${currentQuestion + 1}: ${question.question}`
    const utterance = new SpeechSynthesisUtterance(text)
    speechSynthesis.speak(utterance)
  }

  const finalScore = Math.round((score / quiz.questions.length) * 100)

  if (quizCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-20 w-64 h-64 bg-gradient-to-br from-purple-300 to-pink-300 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-48 h-48 bg-gradient-to-br from-blue-300 to-cyan-300 rounded-full blur-2xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 p-6">
          <div className="max-w-2xl mx-auto space-y-8">
            <Card className="border-2 border-purple-200 bg-white/95 backdrop-blur-sm shadow-2xl">
              <CardHeader className="text-center bg-gradient-to-r from-purple-50 to-pink-50">
                <div className="flex justify-center mb-4">
                  <div className="bg-gradient-to-br from-purple-500 to-pink-600 p-4 rounded-full shadow-lg">
                    <Trophy className="h-12 w-12 text-white" />
                  </div>
                </div>
                <CardTitle className="text-3xl font-bold text-gray-800">Quiz Complete!</CardTitle>
                <p className="text-xl text-gray-600 mt-2">{quiz.title}</p>
              </CardHeader>
              <CardContent className="p-8 text-center space-y-6">
                <div className="space-y-4">
                  <div className="text-6xl font-bold text-purple-600">{finalScore}%</div>
                  <div className="text-xl text-gray-700">
                    You scored {score} out of {quiz.questions.length} questions correctly
                  </div>

                  {finalScore >= 80 && (
                    <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4">
                      <div className="flex items-center justify-center gap-2 text-green-700">
                        <CheckCircle className="h-6 w-6" />
                        <span className="text-lg font-semibold">Excellent Work!</span>
                      </div>
                      <p className="text-green-600 mt-2">You have a great understanding of cyber safety!</p>
                    </div>
                  )}

                  {finalScore >= 60 && finalScore < 80 && (
                    <div className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-4">
                      <div className="flex items-center justify-center gap-2 text-yellow-700">
                        <HelpCircle className="h-6 w-6" />
                        <span className="text-lg font-semibold">Good Job!</span>
                      </div>
                      <p className="text-yellow-600 mt-2">
                        You're on the right track. Review the lessons and try again!
                      </p>
                    </div>
                  )}

                  {finalScore < 60 && (
                    <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-4">
                      <div className="flex items-center justify-center gap-2 text-orange-700">
                        <AlertTriangle className="h-6 w-6" />
                        <span className="text-lg font-semibold">Keep Learning!</span>
                      </div>
                      <p className="text-orange-600 mt-2">
                        Review the course materials and practice more to improve your score.
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex gap-4 justify-center">
                  <Button
                    onClick={handleRestart}
                    className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                    size="lg"
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Retake Quiz
                  </Button>
                  <Link href="/quiz">
                    <Button variant="outline" size="lg" className="bg-white/80 hover:bg-white border-2">
                      Back to Quizzes
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-64 h-64 bg-gradient-to-br from-purple-300 to-pink-300 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-gradient-to-br from-blue-300 to-cyan-300 rounded-full blur-2xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 p-6">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center gap-4">
            <Link href="/quiz">
              <Button variant="outline" size="lg" className="bg-white/80 hover:bg-white border-2">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Quizzes
              </Button>
            </Link>
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg border flex-1">
              <h1 className="text-2xl font-bold text-gray-800">{quiz.title}</h1>
              <p className="text-gray-600">
                Question {currentQuestion + 1} of {quiz.questions.length}
              </p>
            </div>
          </div>

          {/* Progress */}
          <Card className="border-2 border-purple-200 bg-white/90 backdrop-blur-sm shadow-xl">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-3">
                <span className="text-lg font-medium">Quiz Progress</span>
                <Badge className="text-lg px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-600">
                  {Math.round(progress)}%
                </Badge>
              </div>
              <Progress value={progress} className="h-3" />
            </CardContent>
          </Card>

          {/* Question */}
          <Card className="border-2 border-indigo-200 bg-white/95 backdrop-blur-sm shadow-xl">
            <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl flex items-center gap-3">
                  <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-3 rounded-full">
                    <HelpCircle className="h-6 w-6 text-white" />
                  </div>
                  Question {currentQuestion + 1}
                </CardTitle>
                <Button onClick={speakQuestion} variant="outline" size="sm" className="bg-white/80 hover:bg-white">
                  <Volume2 className="h-4 w-4 mr-2" />
                  Listen
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-8">
              <h2 className="text-xl font-semibold text-gray-800 mb-8 leading-relaxed">{question.question}</h2>

              <div className="space-y-4">
                {question.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={showResult}
                    className={`w-full p-6 text-left rounded-xl border-2 transition-all text-lg ${
                      selectedAnswer === index
                        ? showResult
                          ? index === question.correct
                            ? "border-green-500 bg-green-50 text-green-800"
                            : "border-red-500 bg-red-50 text-red-800"
                          : "border-purple-500 bg-purple-50 text-purple-800"
                        : showResult && index === question.correct
                          ? "border-green-500 bg-green-50 text-green-800"
                          : "border-gray-200 bg-white hover:border-purple-300 hover:bg-purple-50 text-gray-700"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold ${
                          selectedAnswer === index
                            ? showResult
                              ? index === question.correct
                                ? "border-green-500 bg-green-500 text-white"
                                : "border-red-500 bg-red-500 text-white"
                              : "border-purple-500 bg-purple-500 text-white"
                            : showResult && index === question.correct
                              ? "border-green-500 bg-green-500 text-white"
                              : "border-gray-300 text-gray-600"
                        }`}
                      >
                        {String.fromCharCode(65 + index)}
                      </div>
                      <span className="flex-1">{option}</span>
                      {showResult &&
                        selectedAnswer === index &&
                        (index === question.correct ? (
                          <CheckCircle className="h-6 w-6 text-green-600" />
                        ) : (
                          <XCircle className="h-6 w-6 text-red-600" />
                        ))}
                      {showResult && index === question.correct && selectedAnswer !== index && (
                        <CheckCircle className="h-6 w-6 text-green-600" />
                      )}
                    </div>
                  </button>
                ))}
              </div>

              {showResult && (
                <Card className="mt-8 border-2 border-blue-200 bg-blue-50">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Shield className="h-5 w-5 text-blue-600" />
                      Explanation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 text-lg leading-relaxed">{question.explanation}</p>
                  </CardContent>
                </Card>
              )}

              <div className="flex justify-end mt-8">
                <Button
                  onClick={handleNext}
                  disabled={selectedAnswer === null || showResult}
                  size="lg"
                  className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                >
                  {currentQuestion === quiz.questions.length - 1 ? "Finish Quiz" : "Next Question"}
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
