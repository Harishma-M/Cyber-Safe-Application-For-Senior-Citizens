"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Smartphone,
  CreditCard,
  Lock,
  Globe,
  ShoppingCart,
  MessageSquare,
  Play,
  Volume2,
  FileText,
  CheckCircle,
  Clock,
  Users,
  Wifi,
} from "lucide-react"
import Link from "next/link"

const learningModules = [
  {
    id: 1,
    title: "Phishing Scams & Email Safety",
    description: "Learn to identify fake emails, messages, and websites that try to steal your personal information",
    icon: MessageSquare,
    duration: "15 min",
    difficulty: "Beginner",
    completed: true,
    progress: 100,
    color: "bg-gradient-to-br from-red-500 to-rose-600",
    lessons: 5,
    content:
      "Understand common phishing tactics, recognize suspicious emails, and learn how to verify legitimate communications from banks and organizations.",
  },
  {
    id: 2,
    title: "OTP & Banking Frauds",
    description: "Understand how scammers trick you into sharing OTPs, PINs, and banking details",
    icon: CreditCard,
    duration: "20 min",
    difficulty: "Beginner",
    completed: true,
    progress: 100,
    color: "bg-gradient-to-br from-blue-500 to-cyan-600",
    lessons: 6,
    content:
      "Learn about One-Time Password security, banking fraud techniques, and how to protect your financial information from scammers.",
  },
  {
    id: 3,
    title: "Password Security & Account Safety",
    description: "Create strong passwords and keep all your online accounts secure",
    icon: Lock,
    duration: "12 min",
    difficulty: "Beginner",
    completed: true,
    progress: 100,
    color: "bg-gradient-to-br from-green-500 to-emerald-600",
    lessons: 4,
    content:
      "Master password creation, understand two-factor authentication, and learn to manage your digital accounts safely.",
  },
  {
    id: 4,
    title: "Fake Apps & Malicious Links",
    description: "Spot dangerous apps and malicious links before they harm your device or steal data",
    icon: Smartphone,
    duration: "18 min",
    difficulty: "Intermediate",
    completed: false,
    progress: 60,
    color: "bg-gradient-to-br from-purple-500 to-violet-600",
    lessons: 7,
    content:
      "Identify fake mobile apps, understand app permissions, and learn to recognize malicious links and downloads.",
  },
  {
    id: 5,
    title: "Social Media Safety",
    description: "Stay safe on Facebook, WhatsApp, Instagram, and other social platforms",
    icon: Users,
    duration: "25 min",
    difficulty: "Intermediate",
    completed: false,
    progress: 0,
    color: "bg-gradient-to-br from-orange-500 to-amber-600",
    lessons: 8,
    content:
      "Learn privacy settings, recognize fake profiles, understand social engineering attacks, and protect your personal information on social media.",
  },
  {
    id: 6,
    title: "Safe Online Shopping & Payments",
    description: "Shop online securely and avoid payment frauds and fake websites",
    icon: ShoppingCart,
    duration: "22 min",
    difficulty: "Intermediate",
    completed: false,
    progress: 0,
    color: "bg-gradient-to-br from-pink-500 to-rose-600",
    lessons: 6,
    content:
      "Identify secure shopping websites, understand payment security, recognize fake online stores, and shop safely online.",
  },
  {
    id: 7,
    title: "WiFi Security & Public Networks",
    description: "Use public WiFi safely and secure your home internet connection",
    icon: Wifi,
    duration: "16 min",
    difficulty: "Advanced",
    completed: false,
    progress: 0,
    color: "bg-gradient-to-br from-teal-500 to-cyan-600",
    lessons: 5,
    content:
      "Understand WiFi security, learn about VPNs, recognize unsafe public networks, and secure your home internet.",
  },
  {
    id: 8,
    title: "Digital Privacy & Data Protection",
    description: "Protect your personal data and maintain privacy in the digital world",
    icon: Globe,
    duration: "20 min",
    difficulty: "Advanced",
    completed: false,
    progress: 0,
    color: "bg-gradient-to-br from-indigo-500 to-purple-600",
    lessons: 7,
    content:
      "Learn about data privacy, understand cookies and tracking, manage your digital footprint, and control your personal information online.",
  },
]

export default function LearnPage() {
  const completedModules = learningModules.filter((module) => module.completed).length
  const totalModules = learningModules.length
  const overallProgress = (completedModules / totalModules) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 relative overflow-hidden">
      {/* Beautiful Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-32 left-16 w-72 h-72 bg-gradient-to-br from-green-300 to-emerald-300 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-80 right-24 w-56 h-56 bg-gradient-to-br from-blue-300 to-cyan-300 rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-40 left-1/4 w-64 h-64 bg-gradient-to-br from-purple-300 to-violet-300 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      <div className="relative z-10 p-6">
        <div className="max-w-6xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-6">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-green-200 inline-block">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                Learn Cyber Safety
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-3">
                Master digital security with our step-by-step lessons designed specifically for seniors
              </p>
            </div>
          </div>

          {/* Progress Overview */}
          <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50 shadow-xl backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <div className="bg-gradient-to-br from-blue-500 to-cyan-600 p-3 rounded-full shadow-lg">
                  <CheckCircle className="h-6 w-6 text-white" />
                </div>
                Your Learning Journey
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">{completedModules}</div>
                  <div className="text-gray-600">Modules Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">{overallProgress.toFixed(0)}%</div>
                  <div className="text-gray-600">Overall Progress</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">3</div>
                  <div className="text-gray-600">Certificates Earned</div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium">Learning Progress</span>
                  <Badge className="text-lg px-4 py-2 bg-gradient-to-r from-blue-500 to-cyan-500">
                    {completedModules}/{totalModules}
                  </Badge>
                </div>
                <Progress value={overallProgress} className="h-4" />
                <p className="text-gray-600 text-center">🎉 You're doing excellent! Keep up the great work!</p>
              </div>
            </CardContent>
          </Card>

          {/* Learning Modules Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {learningModules.map((module) => (
              <Card
                key={module.id}
                className={`border-2 hover:shadow-2xl transition-all duration-300 transform hover:scale-105 ${
                  module.completed
                    ? "border-green-300 bg-gradient-to-br from-green-50 to-emerald-50"
                    : "border-gray-200 hover:border-blue-300 bg-white/90 backdrop-blur-sm"
                }`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div
                      className={`${module.color} p-3 rounded-full shadow-lg transform hover:rotate-6 transition-transform`}
                    >
                      <module.icon className="h-6 w-6 text-white" />
                    </div>
                    {module.completed && (
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-6 w-6 text-green-600" />
                        <Badge className="bg-green-500 text-white">Complete</Badge>
                      </div>
                    )}
                  </div>
                  <CardTitle className="text-xl leading-tight">{module.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">{module.description}</p>

                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm text-gray-700">{module.content}</p>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {module.duration}
                    </div>
                    <div className="flex items-center gap-1">
                      <FileText className="h-4 w-4" />
                      {module.lessons} lessons
                    </div>
                  </div>

                  <Badge
                    variant="outline"
                    className={`text-xs ${
                      module.difficulty === "Beginner"
                        ? "border-green-300 text-green-700"
                        : module.difficulty === "Intermediate"
                          ? "border-yellow-300 text-yellow-700"
                          : "border-red-300 text-red-700"
                    }`}
                  >
                    {module.difficulty}
                  </Badge>

                  {module.progress > 0 && module.progress < 100 && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{module.progress}%</span>
                      </div>
                      <Progress value={module.progress} className="h-2" />
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Link href={`/learn/${module.id}`} className="flex-1">
                      <Button
                        className={`w-full h-12 text-base font-medium ${module.color} hover:opacity-90 shadow-lg`}
                      >
                        <Play className="h-4 w-4 mr-2" />
                        {module.completed ? "Review" : module.progress > 0 ? "Continue" : "Start Learning"}
                      </Button>
                    </Link>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1 bg-white/80 hover:bg-white border-gray-300">
                      <Volume2 className="h-4 w-4 mr-1" />
                      Audio
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 bg-white/80 hover:bg-white border-gray-300">
                      <FileText className="h-4 w-4 mr-1" />
                      Text
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Learning Tips */}
          <Card className="border-2 border-yellow-300 bg-gradient-to-r from-yellow-50 to-orange-50 shadow-xl">
            <CardHeader>
              <CardTitle className="text-xl">💡 Learning Tips for Success</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800 flex items-center gap-2">📱 Before Starting:</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Find a quiet, comfortable place to learn</li>
                    <li>• Use audio mode if you prefer listening</li>
                    <li>• Take breaks every 15-20 minutes</li>
                    <li>• Keep a notebook for important points</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800 flex items-center gap-2">🎯 During Learning:</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Learn at your own comfortable pace</li>
                    <li>• Repeat lessons as many times as needed</li>
                    <li>• Practice with real-life examples</li>
                    <li>• Ask family members to help you practice</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
