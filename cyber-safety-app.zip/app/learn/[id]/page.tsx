"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  ArrowLeft,
  Play,
  Pause,
  Volume2,
  CheckCircle,
  ArrowRight,
  BookOpen,
  AlertTriangle,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useParams } from "next/navigation"

const courseContent = {
  1: {
    title: "Phishing Scams & Email Safety",
    lessons: [
      {
        id: 1,
        title: "What is Phishing?",
        content: `Phishing is when criminals try to trick you into giving them your personal information like passwords, bank details, or credit card numbers. They do this by pretending to be someone you trust, like your bank or a government office.

**Common Signs of Phishing:**
• Urgent messages saying "Act now or your account will be closed"
• Emails asking for your password, PIN, or OTP
• Messages with spelling mistakes or poor grammar
• Links that don't match the real website address
• Unexpected prizes or offers that seem too good to be true

**Real Example:**
"Dear Customer, Your bank account will be suspended in 24 hours. Click here to verify: www.fake-bank-site.com"

This is a phishing attempt because:
- It creates false urgency
- Banks never ask for verification through email
- The website address looks suspicious`,
        duration: "3 min",
        completed: true,
      },
      {
        id: 2,
        title: "Email Safety Rules",
        content: `**Golden Rules for Email Safety:**

1. **Never click suspicious links**
   - Hover over links to see the real address
   - Type website addresses directly in your browser
   - When in doubt, call the organization directly

2. **Verify the sender**
   - Check if the email address looks official
   - Look for spelling mistakes in the sender's name
   - Be suspicious of generic greetings like "Dear Customer"

3. **Protect your information**
   - Never share passwords or PINs via email
   - Don't download attachments from unknown senders
   - Banks and government offices never ask for sensitive info by email

**Safe Practice:**
If you receive an email from your bank, don't click any links. Instead, open a new browser window and type your bank's website address directly.`,
        duration: "4 min",
        completed: true,
      },
      {
        id: 3,
        title: "Recognizing Fake Websites",
        content: `**How to Spot Fake Websites:**

1. **Check the web address (URL)**
   - Real bank websites start with "https://" (note the 's')
   - Look for the padlock symbol in your browser
   - Fake sites often have strange spellings like "bankofindai.com" instead of "bankofindia.com"

2. **Look for security signs**
   - Legitimate websites have proper certificates
   - Your browser will warn you about unsafe sites
   - Never ignore security warnings

3. **Check the website quality**
   - Official websites have professional design
   - Look for contact information and customer service numbers
   - Fake sites often have poor grammar and low-quality images

**Warning Signs:**
• Website asks for too much personal information
• No customer service contact details
• Prices that are too good to be true
• Pressure to "act now" or "limited time offers"`,
        duration: "4 min",
        completed: false,
      },
      {
        id: 4,
        title: "SMS and WhatsApp Scams",
        content: `**Common SMS/WhatsApp Scams:**

1. **Fake Prize Messages**
   "Congratulations! You've won ₹50,000 in KBC lottery. Send your bank details to claim."
   
2. **Fake Bank Alerts**
   "Your account is blocked. Call 9876543210 immediately to unblock."
   
3. **Fake Government Messages**
   "Your Aadhaar card will be cancelled. Click here to update: bit.ly/fake-link"

**How to Stay Safe:**
• Never share OTP, PIN, or passwords with anyone
• Don't click on shortened links (bit.ly, tinyurl, etc.)
• Verify messages by calling official customer service
• Block and report suspicious numbers
• Remember: You can't win a lottery you never entered!

**What to do if you receive a suspicious message:**
1. Don't click any links
2. Don't call any numbers mentioned
3. Block the sender
4. Report to 1930 (cybercrime helpline)
5. Warn your family and friends`,
        duration: "4 min",
        completed: false,
      },
    ],
  },
  2: {
    title: "OTP & Banking Frauds",
    lessons: [
      {
        id: 1,
        title: "Understanding OTP Security",
        content: `**What is OTP?**
OTP stands for One-Time Password. It's a special code sent to your phone that proves you are the real account holder when doing online transactions.

**How OTP Works:**
1. You try to make a payment or login
2. The bank sends a unique code to your registered mobile number
3. You enter this code to complete the transaction
4. The code expires in a few minutes and can only be used once

**Golden Rule: NEVER SHARE YOUR OTP**
• Banks will NEVER ask for your OTP over phone
• Government offices will NEVER ask for OTP
• No legitimate company will ask for your OTP
• OTP is only for you to enter on official websites

**Common OTP Scam:**
Scammer calls: "Sir, I'm calling from your bank. For security verification, please tell me the OTP we just sent to your phone."

**Correct Response:** "Banks never ask for OTP over phone. I'm hanging up and calling the bank directly."`,
        duration: "4 min",
        completed: true,
      },
      {
        id: 2,
        title: "Banking Fraud Techniques",
        content: `**Common Banking Fraud Methods:**

1. **Fake Bank Calls**
   - Scammers pretend to be bank employees
   - They create urgency: "Your account will be blocked"
   - They ask for OTP, PIN, or card details
   
2. **ATM Card Cloning**
   - Criminals attach devices to ATM machines
   - They steal your card information and PIN
   - Always check ATM for unusual attachments

3. **Fake Banking Apps**
   - Criminals create fake banking apps
   - These apps steal your login details
   - Only download apps from official app stores

4. **SIM Swap Fraud**
   - Criminals get a duplicate of your SIM card
   - They receive your OTPs and banking messages
   - Immediately contact your mobile provider if you lose network suddenly

**Protection Tips:**
• Use only official banking apps and websites
• Never share banking details over phone
• Cover your PIN when entering at ATM
• Check your bank statements regularly
• Set up SMS alerts for all transactions`,
        duration: "5 min",
        completed: true,
      },
    ],
  },
}

export default function LessonPage() {
  const params = useParams()
  const courseId = Number.parseInt(params.id as string)
  const [currentLesson, setCurrentLesson] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)

  const course = courseContent[courseId as keyof typeof courseContent]

  if (!course) {
    return <div>Course not found</div>
  }

  const lesson = course.lessons[currentLesson]
  const progress = ((currentLesson + 1) / course.lessons.length) * 100

  const handleNext = () => {
    if (currentLesson < course.lessons.length - 1) {
      setCurrentLesson(currentLesson + 1)
    }
  }

  const handlePrevious = () => {
    if (currentLesson > 0) {
      setCurrentLesson(currentLesson - 1)
    }
  }

  const toggleAudio = () => {
    setIsPlaying(!isPlaying)
    // In a real app, this would control text-to-speech
    if (!isPlaying) {
      const utterance = new SpeechSynthesisUtterance(lesson.content)
      speechSynthesis.speak(utterance)
    } else {
      speechSynthesis.cancel()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-20 w-64 h-64 bg-gradient-to-br from-blue-300 to-cyan-300 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-gradient-to-br from-purple-300 to-pink-300 rounded-full blur-2xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center gap-4">
            <Link href="/learn">
              <Button variant="outline" size="lg" className="bg-white/80 hover:bg-white border-2">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Courses
              </Button>
            </Link>
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg border flex-1">
              <h1 className="text-2xl font-bold text-gray-800">{course.title}</h1>
              <p className="text-gray-600">
                Lesson {currentLesson + 1} of {course.lessons.length}
              </p>
            </div>
          </div>

          {/* Progress */}
          <Card className="border-2 border-blue-200 bg-white/90 backdrop-blur-sm shadow-xl">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-3">
                <span className="text-lg font-medium">Course Progress</span>
                <Badge className="text-lg px-4 py-2 bg-gradient-to-r from-blue-500 to-cyan-500">
                  {Math.round(progress)}%
                </Badge>
              </div>
              <Progress value={progress} className="h-3" />
            </CardContent>
          </Card>

          {/* Lesson Navigation */}
          <Card className="border-2 border-gray-200 bg-white/90 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="text-xl">Course Lessons</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {course.lessons.map((lessonItem, index) => (
                  <button
                    key={lessonItem.id}
                    onClick={() => setCurrentLesson(index)}
                    className={`p-4 rounded-lg border-2 text-left transition-all ${
                      index === currentLesson
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-blue-300 bg-white"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {lessonItem.completed ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <div className="h-5 w-5 rounded-full border-2 border-gray-300" />
                      )}
                      <div>
                        <h3 className="font-medium">{lessonItem.title}</h3>
                        <p className="text-sm text-gray-600">{lessonItem.duration}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Current Lesson */}
          <Card className="border-2 border-indigo-200 bg-white/95 backdrop-blur-sm shadow-xl">
            <CardHeader className="bg-gradient-to-r from-indigo-50 to-blue-50">
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl flex items-center gap-3">
                  <div className="bg-gradient-to-br from-indigo-500 to-blue-600 p-3 rounded-full">
                    <BookOpen className="h-6 w-6 text-white" />
                  </div>
                  {lesson.title}
                </CardTitle>
                <Badge variant="outline" className="text-base px-3 py-1">
                  {lesson.duration}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-8">
              {/* Audio Controls */}
              <div className="flex gap-4 mb-6">
                <Button
                  onClick={toggleAudio}
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                >
                  {isPlaying ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                  {isPlaying ? "Pause Audio" : "Listen to Lesson"}
                </Button>
                <Button variant="outline" className="bg-white/80 hover:bg-white">
                  <Volume2 className="h-4 w-4 mr-2" />
                  Adjust Speed
                </Button>
              </div>

              {/* Lesson Content */}
              <div className="prose prose-lg max-w-none">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
                  {lesson.content.split("\n").map((paragraph, index) => {
                    if (paragraph.startsWith("**") && paragraph.endsWith("**")) {
                      return (
                        <h3 key={index} className="text-xl font-bold text-gray-800 mt-6 mb-3 first:mt-0">
                          {paragraph.replace(/\*\*/g, "")}
                        </h3>
                      )
                    } else if (paragraph.startsWith("•")) {
                      return (
                        <li key={index} className="text-gray-700 ml-4 mb-2">
                          {paragraph.substring(2)}
                        </li>
                      )
                    } else if (paragraph.trim()) {
                      return (
                        <p key={index} className="text-gray-700 mb-4 leading-relaxed text-lg">
                          {paragraph}
                        </p>
                      )
                    }
                    return null
                  })}
                </div>
              </div>

              {/* Key Takeaways */}
              <Card className="mt-8 border-2 border-yellow-200 bg-yellow-50">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                    Key Takeaways
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-gray-700">
                    {currentLesson === 0 && (
                      <>
                        <li>• Phishing is when criminals pretend to be trusted organizations</li>
                        <li>• Never click suspicious links or download unknown attachments</li>
                        <li>• Always verify the sender before sharing any information</li>
                        <li>• When in doubt, contact the organization directly</li>
                      </>
                    )}
                    {currentLesson === 1 && (
                      <>
                        <li>• Never share your OTP with anyone over phone or message</li>
                        <li>• Banks never ask for OTP, PIN, or passwords</li>
                        <li>• Always use official banking websites and apps</li>
                        <li>• Report suspicious calls to cybercrime helpline 1930</li>
                      </>
                    )}
                  </ul>
                </CardContent>
              </Card>
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between items-center">
            <Button
              onClick={handlePrevious}
              disabled={currentLesson === 0}
              variant="outline"
              size="lg"
              className="bg-white/80 hover:bg-white border-2"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous Lesson
            </Button>

            <div className="flex gap-4">
              <Link href="/quiz">
                <Button variant="outline" size="lg" className="bg-white/80 hover:bg-white border-2">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Take Quiz
                </Button>
              </Link>

              {currentLesson < course.lessons.length - 1 ? (
                <Button
                  onClick={handleNext}
                  size="lg"
                  className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700"
                >
                  Next Lesson
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              ) : (
                <Link href="/learn">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Course Complete
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
