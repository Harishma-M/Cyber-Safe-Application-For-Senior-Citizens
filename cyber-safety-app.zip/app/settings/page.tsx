"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Settings, Volume2, Eye, Globe, Moon, Sun, Vibrate, Bell, Shield, Users, Smartphone } from "lucide-react"
import { useState } from "react"

export default function SettingsPage() {
  const [fontSize, setFontSize] = useState([18])
  const [volume, setVolume] = useState([75])
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(true)
  const [isHighContrast, setIsHighContrast] = useState(false)
  const [isVibrateEnabled, setIsVibrateEnabled] = useState(true)
  const [isNotificationsEnabled, setIsNotificationsEnabled] = useState(true)
  const [selectedLanguage, setSelectedLanguage] = useState("english")

  const languages = [
    { value: "english", label: "English", flag: "🇺🇸" },
    { value: "hindi", label: "हिंदी (Hindi)", flag: "🇮🇳" },
    { value: "tamil", label: "தமிழ் (Tamil)", flag: "🇮🇳" },
    { value: "telugu", label: "తెలుగు (Telugu)", flag: "🇮🇳" },
    { value: "malayalam", label: "മലയാളം (Malayalam)", flag: "🇮🇳" },
    { value: "kannada", label: "ಕನ್ನಡ (Kannada)", flag: "🇮🇳" },
    { value: "bengali", label: "বাংলা (Bengali)", flag: "🇮🇳" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="bg-gray-600 p-4 rounded-full">
              <Settings className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800">Settings</h1>
          </div>
          <p className="text-xl text-gray-600">Customize your app experience for better accessibility and comfort</p>
        </div>

        {/* Language Settings */}
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Globe className="h-6 w-6 text-blue-600" />
              Language & Region
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <label className="text-lg font-medium text-gray-700">App Language</label>
              <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                <SelectTrigger className="h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {languages.map((lang) => (
                    <SelectItem key={lang.value} value={lang.value} className="text-base py-3">
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{lang.flag}</span>
                        <span>{lang.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-sm text-gray-600">
                Choose your preferred language for the app interface and voice instructions
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Accessibility Settings */}
        <Card className="border-2 border-green-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Eye className="h-6 w-6 text-green-600" />
              Accessibility
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* Font Size */}
            <div className="space-y-4">
              <label className="text-lg font-medium text-gray-700">Text Size</label>
              <div className="space-y-3">
                <Slider value={fontSize} onValueChange={setFontSize} max={24} min={14} step={2} className="w-full" />
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Small (14px)</span>
                  <span className="font-medium">Current: {fontSize[0]}px</span>
                  <span>Large (24px)</span>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p style={{ fontSize: `${fontSize[0]}px` }} className="text-gray-800">
                    Sample text: This is how your text will appear in the app.
                  </p>
                </div>
              </div>
            </div>

            {/* High Contrast */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800">High Contrast Mode</h3>
                <p className="text-gray-600">Increase contrast for better visibility</p>
              </div>
              <Switch checked={isHighContrast} onCheckedChange={setIsHighContrast} className="scale-125" />
            </div>

            {/* Dark Mode */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800 flex items-center gap-2">
                  {isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
                  Dark Mode
                </h3>
                <p className="text-gray-600">Switch to dark theme for low light conditions</p>
              </div>
              <Switch checked={isDarkMode} onCheckedChange={setIsDarkMode} className="scale-125" />
            </div>
          </CardContent>
        </Card>

        {/* Audio Settings */}
        <Card className="border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Volume2 className="h-6 w-6 text-purple-600" />
              Audio & Voice
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            {/* Voice Assistant */}
            <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800">Voice Assistant</h3>
                <p className="text-gray-600">Enable voice commands and responses</p>
              </div>
              <Switch checked={isVoiceEnabled} onCheckedChange={setIsVoiceEnabled} className="scale-125" />
            </div>

            {/* Volume Control */}
            <div className="space-y-4">
              <label className="text-lg font-medium text-gray-700">Voice Volume</label>
              <div className="space-y-3">
                <Slider value={volume} onValueChange={setVolume} max={100} min={0} step={5} className="w-full" />
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Silent</span>
                  <span className="font-medium">{volume[0]}%</span>
                  <span>Loud</span>
                </div>
              </div>
              <Button variant="outline" className="w-full bg-transparent">
                Test Voice Volume
              </Button>
            </div>

            {/* Vibration */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800 flex items-center gap-2">
                  <Vibrate className="h-5 w-5" />
                  Vibration Feedback
                </h3>
                <p className="text-gray-600">Feel vibrations for button presses and alerts</p>
              </div>
              <Switch checked={isVibrateEnabled} onCheckedChange={setIsVibrateEnabled} className="scale-125" />
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card className="border-2 border-orange-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Bell className="h-6 w-6 text-orange-600" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Push Notifications */}
            <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800">Push Notifications</h3>
                <p className="text-gray-600">Receive alerts about new scams and safety tips</p>
              </div>
              <Switch
                checked={isNotificationsEnabled}
                onCheckedChange={setIsNotificationsEnabled}
                className="scale-125"
              />
            </div>

            {/* Daily Tips */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800">Daily Safety Tips</h3>
                <p className="text-gray-600">Get a helpful tip every day at 9:00 AM</p>
              </div>
              <Switch defaultChecked className="scale-125" />
            </div>

            {/* Emergency Alerts */}
            <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800">Emergency Alerts</h3>
                <p className="text-gray-600">Urgent scam warnings in your area</p>
              </div>
              <Switch defaultChecked className="scale-125" />
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="border-2 border-red-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Shield className="h-6 w-6 text-red-600" />
              Security & Privacy
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* App Lock */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-800">App Lock Method</h3>
              <Select defaultValue="pin">
                <SelectTrigger className="h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none" className="text-base py-3">
                    No Lock
                  </SelectItem>
                  <SelectItem value="pin" className="text-base py-3">
                    4-Digit PIN
                  </SelectItem>
                  <SelectItem value="pattern" className="text-base py-3">
                    Pattern Lock
                  </SelectItem>
                  <SelectItem value="fingerprint" className="text-base py-3">
                    Fingerprint
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Auto Logout */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-800">Auto Logout</h3>
              <Select defaultValue="30">
                <SelectTrigger className="h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="never" className="text-base py-3">
                    Never
                  </SelectItem>
                  <SelectItem value="15" className="text-base py-3">
                    15 minutes
                  </SelectItem>
                  <SelectItem value="30" className="text-base py-3">
                    30 minutes
                  </SelectItem>
                  <SelectItem value="60" className="text-base py-3">
                    1 hour
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Family Settings */}
        <Card className="border-2 border-indigo-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Users className="h-6 w-6 text-indigo-600" />
              Family Mode
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-indigo-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800">Allow Family Monitoring</h3>
                <p className="text-gray-600">Let family members see your learning progress</p>
              </div>
              <Switch defaultChecked className="scale-125" />
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="space-y-1">
                <h3 className="text-lg font-medium text-gray-800">Emergency Contacts Access</h3>
                <p className="text-gray-600">Family can receive emergency alerts</p>
              </div>
              <Switch defaultChecked className="scale-125" />
            </div>
          </CardContent>
        </Card>

        {/* Device Settings */}
        <Card className="border-2 border-teal-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Smartphone className="h-6 w-6 text-teal-600" />
              Device Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button variant="outline" className="h-12 text-base bg-transparent">
                Clear App Cache
              </Button>
              <Button variant="outline" className="h-12 text-base bg-transparent">
                Download Offline Content
              </Button>
              <Button variant="outline" className="h-12 text-base bg-transparent">
                Export Learning Data
              </Button>
              <Button variant="outline" className="h-12 text-base bg-transparent">
                Reset All Settings
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Save Settings */}
        <div className="flex gap-4 justify-center">
          <Button className="h-14 px-8 text-lg font-medium bg-blue-600 hover:bg-blue-700">Save All Settings</Button>
          <Button variant="outline" className="h-14 px-8 text-lg font-medium bg-transparent">
            Reset to Default
          </Button>
        </div>
      </div>
    </div>
  )
}
