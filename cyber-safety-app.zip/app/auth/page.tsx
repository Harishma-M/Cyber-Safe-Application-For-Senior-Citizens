"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Shield,
  User,
  Mail,
  Lock,
  Phone,
  MapPin,
  Eye,
  EyeOff,
  Sparkles,
  AlertCircle,
  CheckCircle,
  Loader2,
  MessageSquare,
  Send,
} from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"

interface UserData {
  id: string
  name: string
  email: string
  password: string
  phone: string
  address: string
  city: string
  state: string
  userType: "senior" | "family" | "caregiver"
  joinDate: string
  isVerified: boolean
  emailVerified: boolean
  phoneVerified: boolean
  verificationCode?: string
  verificationExpiry?: string
}

// Mock database - In real app, this would be a backend API
const mockUsers: UserData[] = [
  {
    id: "1",
    name: "Lakshmi Devi",
    email: "lakshmi@example.com",
    password: "password123",
    phone: "+91 98765 43210",
    address: "123 MG Road",
    city: "Bangalore",
    state: "Karnataka",
    userType: "senior",
    joinDate: "2024-01-15",
    isVerified: true,
    emailVerified: true,
    phoneVerified: true,
  },
  {
    id: "2",
    name: "Ravi Kumar",
    email: "ravi@example.com",
    password: "family123",
    phone: "+91 87654 32109",
    address: "456 Park Street",
    city: "Mumbai",
    state: "Maharashtra",
    userType: "family",
    joinDate: "2024-02-01",
    isVerified: true,
    emailVerified: true,
    phoneVerified: true,
  },
]

// Mock email verification service
const mockEmailService = {
  async sendVerificationEmail(email: string, code: string): Promise<boolean> {
    console.log(`📧 Verification email sent to ${email} with code: ${code}`)

    // Also show an alert for testing purposes
    alert(`📧 DEMO MODE: Your email verification code is: ${code}\n\nIn a real app, this would be sent to ${email}`)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))
    return true
  },

  async sendSMS(phone: string, code: string): Promise<boolean> {
    console.log(`📱 SMS sent to ${phone} with code: ${code}`)

    // Also show an alert for testing purposes
    alert(`📱 DEMO MODE: Your SMS verification code is: ${code}\n\nIn a real app, this would be sent to ${phone}`)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))
    return true
  },
}

export default function AuthPage() {
  const [isSignUp, setIsSignUp] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null)
  const [verificationStep, setVerificationStep] = useState<"form" | "email" | "phone" | "complete">("form")
  const [pendingUser, setPendingUser] = useState<UserData | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    userType: "senior" as "senior" | "family" | "caregiver",
  })

  const [verificationData, setVerificationData] = useState({
    emailCode: "",
    phoneCode: "",
    emailSent: false,
    phoneSent: false,
  })

  const [errors, setErrors] = useState<Record<string, string>>({})
  const router = useRouter()

  const indianStates = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Delhi",
    "Jammu and Kashmir",
    "Ladakh",
  ]

  const userTypes = [
    { value: "senior", label: "Senior Citizen (60+ years)", description: "I want to learn cyber safety" },
    { value: "family", label: "Family Member", description: "I want to help my elderly family members" },
    { value: "caregiver", label: "Caregiver/Helper", description: "I assist elderly people professionally" },
  ]

  // Enhanced email validation
  const validateEmail = (email: string): { isValid: boolean; error?: string } => {
    if (!email) {
      return { isValid: false, error: "Email is required" }
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
    if (!emailRegex.test(email)) {
      return { isValid: false, error: "Please enter a valid email address" }
    }

    // Check for common email providers
    const commonProviders = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "rediffmail.com", "yahoo.co.in"]
    const domain = email.split("@")[1]?.toLowerCase()

    if (!commonProviders.includes(domain) && !domain?.includes(".")) {
      return { isValid: false, error: "Please use a valid email provider (Gmail, Yahoo, Outlook, etc.)" }
    }

    // Check for suspicious patterns
    if (email.includes("..") || email.startsWith(".") || email.endsWith(".")) {
      return { isValid: false, error: "Email format is invalid" }
    }

    return { isValid: true }
  }

  const validatePhone = (phone: string): { isValid: boolean; error?: string } => {
    if (!phone) {
      return { isValid: false, error: "Phone number is required" }
    }

    const cleanPhone = phone.replace(/\s+/g, "").replace(/[()-]/g, "")
    const phoneRegex = /^(\+91|91)?[6-9]\d{9}$/

    if (!phoneRegex.test(cleanPhone)) {
      return { isValid: false, error: "Please enter a valid Indian mobile number (10 digits starting with 6-9)" }
    }

    return { isValid: true }
  }

  const validatePassword = (password: string): { isValid: boolean; error?: string } => {
    if (!password) {
      return { isValid: false, error: "Password is required" }
    }

    if (password.length < 6) {
      return { isValid: false, error: "Password must be at least 6 characters long" }
    }

    return { isValid: true }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    // Email validation
    const emailValidation = validateEmail(formData.email)
    if (!emailValidation.isValid) {
      newErrors.email = emailValidation.error!
    }

    // Password validation
    const passwordValidation = validatePassword(formData.password)
    if (!passwordValidation.isValid) {
      newErrors.password = passwordValidation.error!
    }

    // Sign up specific validations
    if (isSignUp) {
      if (!formData.name.trim()) {
        newErrors.name = "Full name is required"
      } else if (formData.name.trim().length < 2) {
        newErrors.name = "Name must be at least 2 characters long"
      }

      // Phone validation
      const phoneValidation = validatePhone(formData.phone)
      if (!phoneValidation.isValid) {
        newErrors.phone = phoneValidation.error!
      }

      if (!formData.address.trim()) {
        newErrors.address = "Address is required"
      }

      if (!formData.city.trim()) {
        newErrors.city = "City is required"
      }

      if (!formData.state) {
        newErrors.state = "State is required"
      }

      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = "Passwords do not match"
      }

      // Check if email already exists
      const existingUser = mockUsers.find((user) => user.email.toLowerCase() === formData.email.toLowerCase())
      if (existingUser) {
        newErrors.email = "An account with this email already exists"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const generateVerificationCode = (): string => {
    return Math.floor(100000 + Math.random() * 900000).toString()
  }

  const handleSignIn = async () => {
    setIsLoading(true)
    setMessage(null)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Find user in mock database
    const user = mockUsers.find(
      (u) => u.email.toLowerCase() === formData.email.toLowerCase() && u.password === formData.password,
    )

    if (user) {
      if (!user.emailVerified) {
        setMessage({ type: "error", text: "Please verify your email address before signing in." })
        setIsLoading(false)
        return
      }

      // Store user data in localStorage
      localStorage.setItem("currentUser", JSON.stringify(user))
      localStorage.setItem("isAuthenticated", "true")

      setMessage({ type: "success", text: `Welcome back, ${user.name}!` })

      setTimeout(() => {
        router.push("/")
      }, 1000)
    } else {
      setMessage({ type: "error", text: "Invalid email or password. Please check your credentials and try again." })
    }

    setIsLoading(false)
  }

  const handleSignUp = async () => {
    setIsLoading(true)
    setMessage(null)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Create new user with verification codes
    const emailCode = generateVerificationCode()
    const phoneCode = generateVerificationCode()

    const newUser: UserData = {
      id: Date.now().toString(),
      name: formData.name,
      email: formData.email,
      password: formData.password,
      phone: formData.phone,
      address: formData.address,
      city: formData.city,
      state: formData.state,
      userType: formData.userType,
      joinDate: new Date().toISOString(),
      isVerified: false,
      emailVerified: false,
      phoneVerified: false,
      verificationCode: emailCode,
      verificationExpiry: new Date(Date.now() + 10 * 60 * 1000).toISOString(), // 10 minutes
    }

    setPendingUser(newUser)
    setVerificationStep("email")

    // Send verification email
    try {
      await mockEmailService.sendVerificationEmail(formData.email, emailCode)
      setVerificationData((prev) => ({ ...prev, emailSent: true }))
      setMessage({
        type: "info",
        text: `Verification code sent to ${formData.email}. Please check your inbox and spam folder.`,
      })
    } catch (error) {
      setMessage({ type: "error", text: "Failed to send verification email. Please try again." })
    }

    setIsLoading(false)
  }

  const handleEmailVerification = async () => {
    if (!pendingUser || !verificationData.emailCode) {
      setMessage({ type: "error", text: "Please enter the verification code." })
      return
    }

    setIsLoading(true)

    // Simulate API verification
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (verificationData.emailCode === pendingUser.verificationCode) {
      const updatedUser = { ...pendingUser, emailVerified: true }
      setPendingUser(updatedUser)
      setVerificationStep("phone")

      // Send SMS verification
      const phoneCode = generateVerificationCode()
      updatedUser.verificationCode = phoneCode
      setPendingUser(updatedUser)

      try {
        await mockEmailService.sendSMS(formData.phone, phoneCode)
        setVerificationData((prev) => ({ ...prev, phoneSent: true, emailCode: "" }))
        setMessage({
          type: "success",
          text: `Email verified! SMS verification code sent to ${formData.phone}`,
        })
      } catch (error) {
        setMessage({ type: "error", text: "Failed to send SMS verification. Please try again." })
      }
    } else {
      setMessage({ type: "error", text: "Invalid verification code. Please check and try again." })
    }

    setIsLoading(false)
  }

  const handlePhoneVerification = async () => {
    if (!pendingUser || !verificationData.phoneCode) {
      setMessage({ type: "error", text: "Please enter the SMS verification code." })
      return
    }

    setIsLoading(true)

    // Simulate API verification
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (verificationData.phoneCode === pendingUser.verificationCode) {
      const verifiedUser = {
        ...pendingUser,
        phoneVerified: true,
        isVerified: true,
        verificationCode: undefined,
        verificationExpiry: undefined,
      }

      // Add to mock database
      mockUsers.push(verifiedUser)

      // Store user data
      localStorage.setItem("currentUser", JSON.stringify(verifiedUser))
      localStorage.setItem("isAuthenticated", "true")

      setVerificationStep("complete")
      setMessage({
        type: "success",
        text: `Account verified successfully! Welcome to CyberSafe, ${verifiedUser.name}!`,
      })

      setTimeout(() => {
        router.push("/")
      }, 2000)
    } else {
      setMessage({ type: "error", text: "Invalid SMS verification code. Please check and try again." })
    }

    setIsLoading(false)
  }

  const resendVerificationCode = async (type: "email" | "phone") => {
    if (!pendingUser) return

    setIsLoading(true)
    const newCode = generateVerificationCode()

    try {
      if (type === "email") {
        await mockEmailService.sendVerificationEmail(pendingUser.email, newCode)
        setMessage({ type: "success", text: "New verification code sent to your email!" })
      } else {
        await mockEmailService.sendSMS(pendingUser.phone, newCode)
        setMessage({ type: "success", text: "New verification code sent to your phone!" })
      }

      setPendingUser({ ...pendingUser, verificationCode: newCode })
    } catch (error) {
      setMessage({ type: "error", text: `Failed to resend ${type} verification code.` })
    }

    setIsLoading(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (verificationStep === "form") {
      if (!validateForm()) {
        return
      }

      if (isSignUp) {
        await handleSignUp()
      } else {
        await handleSignIn()
      }
    } else if (verificationStep === "email") {
      await handleEmailVerification()
    } else if (verificationStep === "phone") {
      await handlePhoneVerification()
    }
  }

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      userType: "senior",
    })
    setVerificationData({
      emailCode: "",
      phoneCode: "",
      emailSent: false,
      phoneSent: false,
    })
    setErrors({})
    setMessage(null)
    setVerificationStep("form")
    setPendingUser(null)
  }

  const toggleMode = () => {
    setIsSignUp(!isSignUp)
    resetForm()
  }

  // Render verification steps
  if (verificationStep === "email") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-100 via-sky-50 to-emerald-100 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-br from-blue-400/20 via-cyan-400/20 to-emerald-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-60 right-32 w-80 h-80 bg-gradient-to-br from-purple-400/20 via-pink-400/20 to-rose-400/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 flex items-center justify-center min-h-screen p-6">
          <Card className="w-full max-w-lg border-0 shadow-2xl bg-white/90 backdrop-blur-xl rounded-3xl overflow-hidden">
            <CardHeader className="text-center space-y-6 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white rounded-t-3xl relative overflow-hidden">
              <div className="relative z-10 flex items-center justify-center gap-4">
                <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-lg border border-white/30">
                  <Mail className="h-12 w-12 text-white" />
                </div>
                <div>
                  <CardTitle className="text-3xl font-bold">Verify Your Email</CardTitle>
                  <p className="text-blue-100 text-lg">Check your inbox for verification code</p>
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-8 space-y-6">
              <div className="text-center space-y-3">
                <p className="text-xl text-gray-700">We've sent a 6-digit verification code to:</p>
                <p className="text-2xl font-bold text-blue-600">{pendingUser?.email}</p>
                <p className="text-gray-600">
                  Please check your inbox and spam folder. The code will expire in 10 minutes.
                </p>
              </div>

              {message && (
                <Alert
                  className={`border-2 ${
                    message.type === "success"
                      ? "border-green-200 bg-green-50"
                      : message.type === "error"
                        ? "border-red-200 bg-red-50"
                        : "border-blue-200 bg-blue-50"
                  }`}
                >
                  {message.type === "success" ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : message.type === "error" ? (
                    <AlertCircle className="h-4 w-4 text-red-600" />
                  ) : (
                    <Mail className="h-4 w-4 text-blue-600" />
                  )}
                  <AlertDescription
                    className={`font-medium ${
                      message.type === "success"
                        ? "text-green-800"
                        : message.type === "error"
                          ? "text-red-800"
                          : "text-blue-800"
                    }`}
                  >
                    {message.text}
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="emailCode" className="text-lg font-semibold text-gray-700">
                    Enter 6-digit verification code
                  </Label>
                  <Input
                    id="emailCode"
                    type="text"
                    placeholder="123456"
                    value={verificationData.emailCode}
                    onChange={(e) =>
                      setVerificationData((prev) => ({
                        ...prev,
                        emailCode: e.target.value.replace(/\D/g, "").slice(0, 6),
                      }))
                    }
                    className="h-14 text-2xl text-center rounded-xl border-2 border-gray-200 focus:border-blue-400 focus:bg-blue-50 tracking-widest"
                    maxLength={6}
                    disabled={isLoading}
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isLoading || verificationData.emailCode.length !== 6}
                  className="w-full h-14 text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-xl shadow-lg"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-3">
                      <Loader2 className="w-6 h-6 animate-spin" />
                      Verifying...
                    </div>
                  ) : (
                    "Verify Email"
                  )}
                </Button>
              </form>

              <div className="text-center space-y-4">
                <p className="text-gray-600">Didn't receive the code?</p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => resendVerificationCode("email")}
                  disabled={isLoading}
                  className="bg-white/80 hover:bg-white border-2 border-blue-200"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Resend Code
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (verificationStep === "phone") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-100 via-sky-50 to-emerald-100 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-br from-green-400/20 via-emerald-400/20 to-teal-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-60 right-32 w-80 h-80 bg-gradient-to-br from-purple-400/20 via-pink-400/20 to-rose-400/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 flex items-center justify-center min-h-screen p-6">
          <Card className="w-full max-w-lg border-0 shadow-2xl bg-white/90 backdrop-blur-xl rounded-3xl overflow-hidden">
            <CardHeader className="text-center space-y-6 bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 text-white rounded-t-3xl relative overflow-hidden">
              <div className="relative z-10 flex items-center justify-center gap-4">
                <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-lg border border-white/30">
                  <MessageSquare className="h-12 w-12 text-white" />
                </div>
                <div>
                  <CardTitle className="text-3xl font-bold">Verify Your Phone</CardTitle>
                  <p className="text-green-100 text-lg">Check your SMS for verification code</p>
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-8 space-y-6">
              <div className="text-center space-y-3">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <span className="text-green-600 font-medium">Email Verified Successfully!</span>
                </div>
                <p className="text-xl text-gray-700">We've sent a 6-digit SMS code to:</p>
                <p className="text-2xl font-bold text-green-600">{pendingUser?.phone}</p>
                <p className="text-gray-600">
                  Please enter the code from your SMS. The code will expire in 10 minutes.
                </p>
              </div>

              {message && (
                <Alert
                  className={`border-2 ${
                    message.type === "success"
                      ? "border-green-200 bg-green-50"
                      : message.type === "error"
                        ? "border-red-200 bg-red-50"
                        : "border-blue-200 bg-blue-50"
                  }`}
                >
                  {message.type === "success" ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : message.type === "error" ? (
                    <AlertCircle className="h-4 w-4 text-red-600" />
                  ) : (
                    <MessageSquare className="h-4 w-4 text-blue-600" />
                  )}
                  <AlertDescription
                    className={`font-medium ${
                      message.type === "success"
                        ? "text-green-800"
                        : message.type === "error"
                          ? "text-red-800"
                          : "text-blue-800"
                    }`}
                  >
                    {message.text}
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="phoneCode" className="text-lg font-semibold text-gray-700">
                    Enter 6-digit SMS code
                  </Label>
                  <Input
                    id="phoneCode"
                    type="text"
                    placeholder="123456"
                    value={verificationData.phoneCode}
                    onChange={(e) =>
                      setVerificationData((prev) => ({
                        ...prev,
                        phoneCode: e.target.value.replace(/\D/g, "").slice(0, 6),
                      }))
                    }
                    className="h-14 text-2xl text-center rounded-xl border-2 border-gray-200 focus:border-green-400 focus:bg-green-50 tracking-widest"
                    maxLength={6}
                    disabled={isLoading}
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isLoading || verificationData.phoneCode.length !== 6}
                  className="w-full h-14 text-xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 rounded-xl shadow-lg"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-3">
                      <Loader2 className="w-6 h-6 animate-spin" />
                      Verifying...
                    </div>
                  ) : (
                    "Complete Verification"
                  )}
                </Button>
              </form>

              <div className="text-center space-y-4">
                <p className="text-gray-600">Didn't receive the SMS?</p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => resendVerificationCode("phone")}
                  disabled={isLoading}
                  className="bg-white/80 hover:bg-white border-2 border-green-200"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Resend SMS Code
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (verificationStep === "complete") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-100 via-sky-50 to-emerald-100 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-br from-green-400/20 via-emerald-400/20 to-teal-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-60 right-32 w-80 h-80 bg-gradient-to-br from-blue-400/20 via-cyan-400/20 to-indigo-400/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative z-10 flex items-center justify-center min-h-screen p-6">
          <Card className="w-full max-w-lg border-0 shadow-2xl bg-white/90 backdrop-blur-xl rounded-3xl overflow-hidden">
            <CardContent className="p-12 text-center space-y-8">
              <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-6 rounded-full w-24 h-24 mx-auto shadow-2xl">
                <CheckCircle className="h-12 w-12 text-white" />
              </div>

              <div className="space-y-4">
                <h2 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                  Welcome to CyberSafe!
                </h2>
                <p className="text-xl text-gray-700">Your account has been successfully verified and created.</p>
                <p className="text-gray-600">You'll be redirected to your dashboard in a moment...</p>
              </div>

              <div className="flex items-center justify-center gap-2">
                <Loader2 className="h-6 w-6 animate-spin text-green-600" />
                <span className="text-green-600 font-medium">Setting up your account...</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Main form (sign in/sign up)
  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-100 via-sky-50 to-emerald-100 relative overflow-hidden">
      {/* Enhanced Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-br from-blue-400/20 via-cyan-400/20 to-emerald-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-60 right-32 w-80 h-80 bg-gradient-to-br from-purple-400/20 via-pink-400/20 to-rose-400/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-32 left-1/3 w-72 h-72 bg-gradient-to-br from-indigo-400/20 via-blue-400/20 to-cyan-400/20 rounded-full blur-3xl animate-pulse delay-2000"></div>

        {/* Floating geometric shapes */}
        <div className="absolute top-1/4 left-10 w-20 h-20 border-4 border-blue-300/30 rotate-45 animate-spin"></div>
        <div className="absolute bottom-1/4 right-10 w-24 h-24 border-4 border-purple-300/30 rounded-full animate-bounce"></div>
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen p-6">
        <Card className="w-full max-w-2xl border-0 shadow-2xl bg-white/90 backdrop-blur-xl rounded-3xl overflow-hidden">
          {/* Animated Header */}
          <CardHeader className="text-center space-y-6 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white rounded-t-3xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 via-purple-600/90 to-indigo-600/90"></div>
            <div className="absolute inset-0">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/10 to-transparent animate-pulse"></div>
            </div>

            <div className="relative z-10 flex items-center justify-center gap-4">
              <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-lg border border-white/30 animate-pulse">
                <Shield className="h-12 w-12 text-white" />
              </div>
              <div>
                <CardTitle className="text-4xl font-bold flex items-center gap-2">
                  CyberSafe
                  <Sparkles className="h-8 w-8 text-yellow-300 animate-spin" />
                </CardTitle>
                <p className="text-blue-100 text-xl">Digital Security for Everyone</p>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-8 space-y-6">
            {/* Dynamic Title */}
            <div className="text-center space-y-3">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {isSignUp ? "Create Your Account" : "Welcome Back!"}
              </h2>
              <p className="text-gray-600 text-xl">
                {isSignUp
                  ? "Join our community with verified email and phone"
                  : "Sign in to continue learning and staying safe online"}
              </p>
            </div>

            {/* Demo Credentials for Sign In */}
            {!isSignUp && (
              <Alert className="border-blue-200 bg-blue-50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-sm">
                  <strong>Demo Credentials (Already Verified):</strong>
                  <br />
                  Senior: lakshmi@example.com / password123
                  <br />
                  Family: ravi@example.com / family123
                </AlertDescription>
              </Alert>
            )}

            {/* Success/Error Messages */}
            {message && (
              <Alert
                className={`border-2 ${
                  message.type === "success"
                    ? "border-green-200 bg-green-50"
                    : message.type === "error"
                      ? "border-red-200 bg-red-50"
                      : "border-blue-200 bg-blue-50"
                }`}
              >
                {message.type === "success" ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : message.type === "error" ? (
                  <AlertCircle className="h-4 w-4 text-red-600" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                )}
                <AlertDescription
                  className={`font-medium ${
                    message.type === "success"
                      ? "text-green-800"
                      : message.type === "error"
                        ? "text-red-800"
                        : "text-blue-800"
                  }`}
                >
                  {message.text}
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* User Type Selection - Only for Sign Up */}
              {isSignUp && (
                <div className="space-y-3">
                  <Label className="text-lg font-semibold text-gray-700">I am a:</Label>
                  <div className="grid grid-cols-1 gap-3">
                    {userTypes.map((type) => (
                      <button
                        key={type.value}
                        type="button"
                        onClick={() => setFormData({ ...formData, userType: type.value as any })}
                        className={`p-4 rounded-xl border-2 text-left transition-all duration-300 ${
                          formData.userType === type.value
                            ? "border-blue-500 bg-blue-50 shadow-lg"
                            : "border-gray-200 hover:border-blue-300 hover:bg-blue-50"
                        }`}
                      >
                        <div className="font-semibold text-gray-800">{type.label}</div>
                        <div className="text-sm text-gray-600 mt-1">{type.description}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Name Field - Only for Sign Up */}
              {isSignUp && (
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                    <User className="h-5 w-5 text-blue-600" />
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className={`h-14 text-lg rounded-xl border-2 transition-all duration-300 ${
                      errors.name
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                    }`}
                    disabled={isLoading}
                  />
                  {errors.name && <p className="text-red-500 text-sm font-medium">{errors.name}</p>}
                </div>
              )}

              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                  <Mail className="h-5 w-5 text-blue-600" />
                  Email Address * {isSignUp && <span className="text-sm text-gray-500">(will be verified)</span>}
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@gmail.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value.toLowerCase() })}
                  className={`h-14 text-lg rounded-xl border-2 transition-all duration-300 ${
                    errors.email ? "border-red-400 bg-red-50" : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                  }`}
                  disabled={isLoading}
                />
                {errors.email && <p className="text-red-500 text-sm font-medium">{errors.email}</p>}
                {isSignUp && !errors.email && formData.email && (
                  <p className="text-green-600 text-sm flex items-center gap-1">
                    <CheckCircle className="h-4 w-4" />
                    Email format looks good!
                  </p>
                )}
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                  <Lock className="h-5 w-5 text-blue-600" />
                  Password * {isSignUp && <span className="text-sm text-gray-500">(minimum 6 characters)</span>}
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={`h-14 text-lg rounded-xl border-2 pr-14 transition-all duration-300 ${
                      errors.password
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                    }`}
                    disabled={isLoading}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-3 top-1/2 -translate-y-1/2 hover:bg-blue-100"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5 text-gray-500" />
                    ) : (
                      <Eye className="h-5 w-5 text-gray-500" />
                    )}
                  </Button>
                </div>
                {errors.password && <p className="text-red-500 text-sm font-medium">{errors.password}</p>}
              </div>

              {/* Confirm Password - Only for Sign Up */}
              {isSignUp && (
                <div className="space-y-2">
                  <Label
                    htmlFor="confirmPassword"
                    className="text-lg font-semibold flex items-center gap-2 text-gray-700"
                  >
                    <Lock className="h-5 w-5 text-blue-600" />
                    Confirm Password *
                  </Label>
                  <Input
                    id="confirmPassword"
                    type={showPassword ? "text" : "password"}
                    placeholder="Confirm your password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className={`h-14 text-lg rounded-xl border-2 transition-all duration-300 ${
                      errors.confirmPassword
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                    }`}
                    disabled={isLoading}
                  />
                  {errors.confirmPassword && (
                    <p className="text-red-500 text-sm font-medium">{errors.confirmPassword}</p>
                  )}
                  {!errors.confirmPassword &&
                    formData.confirmPassword &&
                    formData.password === formData.confirmPassword && (
                      <p className="text-green-600 text-sm flex items-center gap-1">
                        <CheckCircle className="h-4 w-4" />
                        Passwords match!
                      </p>
                    )}
                </div>
              )}

              {/* Phone Number - Only for Sign Up */}
              {isSignUp && (
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                    <Phone className="h-5 w-5 text-blue-600" />
                    Phone Number * <span className="text-sm text-gray-500">(will be verified via SMS)</span>
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+91 98765 43210"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className={`h-14 text-lg rounded-xl border-2 transition-all duration-300 ${
                      errors.phone
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                    }`}
                    disabled={isLoading}
                  />
                  {errors.phone && <p className="text-red-500 text-sm font-medium">{errors.phone}</p>}
                  {!errors.phone && formData.phone && validatePhone(formData.phone).isValid && (
                    <p className="text-green-600 text-sm flex items-center gap-1">
                      <CheckCircle className="h-4 w-4" />
                      Phone number format is valid!
                    </p>
                  )}
                </div>
              )}

              {/* Address Fields - Only for Sign Up */}
              {isSignUp && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="address" className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                      <MapPin className="h-5 w-5 text-blue-600" />
                      Address *
                    </Label>
                    <Input
                      id="address"
                      type="text"
                      placeholder="House/Flat number, Street name"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className={`h-14 text-lg rounded-xl border-2 transition-all duration-300 ${
                        errors.address
                          ? "border-red-400 bg-red-50"
                          : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                      }`}
                      disabled={isLoading}
                    />
                    {errors.address && <p className="text-red-500 text-sm font-medium">{errors.address}</p>}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city" className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                        <MapPin className="h-5 w-5 text-blue-600" />
                        City *
                      </Label>
                      <Input
                        id="city"
                        type="text"
                        placeholder="Your city"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className={`h-14 text-lg rounded-xl border-2 transition-all duration-300 ${
                          errors.city
                            ? "border-red-400 bg-red-50"
                            : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                        }`}
                        disabled={isLoading}
                      />
                      {errors.city && <p className="text-red-500 text-sm font-medium">{errors.city}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="state" className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                        <MapPin className="h-5 w-5 text-blue-600" />
                        State *
                      </Label>
                      <Select
                        value={formData.state}
                        onValueChange={(value) => setFormData({ ...formData, state: value })}
                        disabled={isLoading}
                      >
                        <SelectTrigger
                          className={`h-14 text-lg rounded-xl border-2 transition-all duration-300 ${
                            errors.state ? "border-red-400 bg-red-50" : "border-gray-200 focus:border-blue-400"
                          }`}
                        >
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          {indianStates.map((state) => (
                            <SelectItem key={state} value={state} className="text-lg py-3">
                              {state}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.state && <p className="text-red-500 text-sm font-medium">{errors.state}</p>}
                    </div>
                  </div>
                </>
              )}

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-16 text-xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-700 rounded-xl shadow-lg transform transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isLoading ? (
                  <div className="flex items-center gap-3">
                    <Loader2 className="w-6 h-6 animate-spin" />
                    {isSignUp ? "Creating Account..." : "Signing In..."}
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    {isSignUp ? "Create Account & Verify" : "Sign In"}
                    <Sparkles className="h-5 w-5" />
                  </div>
                )}
              </Button>
            </form>

            {/* Toggle Sign In/Sign Up */}
            <div className="text-center space-y-4">
              <p className="text-gray-600 text-lg">
                {isSignUp ? "Already have an account?" : "Don't have an account?"}
              </p>
              <Button
                type="button"
                variant="outline"
                onClick={toggleMode}
                disabled={isLoading}
                className="w-full h-14 text-lg border-2 border-blue-200 hover:bg-blue-50 hover:border-blue-400 rounded-xl transition-all duration-300 bg-transparent"
              >
                {isSignUp ? "Sign In Instead" : "Create New Account"}
              </Button>
            </div>

            {/* Terms and Privacy */}
            {isSignUp && (
              <div className="text-center text-sm text-gray-500 space-y-3 bg-gray-50 rounded-xl p-4">
                <p className="font-medium">By creating an account, you agree to our</p>
                <div className="flex justify-center gap-4">
                  <button className="text-blue-600 hover:underline font-medium">Terms of Service</button>
                  <span>•</span>
                  <button className="text-blue-600 hover:underline font-medium">Privacy Policy</button>
                </div>
                <p className="text-xs text-gray-400 mt-2">
                  📧 Email and 📱 SMS verification required for account security
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
