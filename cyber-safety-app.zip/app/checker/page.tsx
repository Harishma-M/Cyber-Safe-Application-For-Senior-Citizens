"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { MessageSquare, Upload, AlertTriangle, CheckCircle, Shield, Eye, Trash2, History } from "lucide-react"
import { useState } from "react"

export default function MessageCheckerPage() {
  const [messageText, setMessageText] = useState("")
  const [analysisResult, setAnalysisResult] = useState<any>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const recentChecks = [
    {
      id: 1,
      message: "Congratulations! You've won ₹50,000. Click here to claim: bit.ly/claim123",
      result: "suspicious",
      timestamp: "2 hours ago",
      threats: ["Suspicious link", "Too good to be true", "Urgency tactics"],
    },
    {
      id: 2,
      message: "Your OTP for bank transaction is 123456. Do not share with anyone.",
      result: "safe",
      timestamp: "1 day ago",
      threats: [],
    },
    {
      id: 3,
      message: "Dear customer, your account will be blocked. Call 9876543210 immediately.",
      result: "dangerous",
      timestamp: "3 days ago",
      threats: ["Fake urgency", "Suspicious phone number", "Account threat"],
    },
  ]

  const handleAnalyzeMessage = async () => {
    if (!messageText.trim()) return

    setIsAnalyzing(true)

    // Simulate AI analysis
    setTimeout(() => {
      const suspiciousKeywords = ["win", "congratulations", "click here", "urgent", "account blocked", "otp", "pin"]
      const foundKeywords = suspiciousKeywords.filter((keyword) => messageText.toLowerCase().includes(keyword))

      let result = "safe"
      const threats: string[] = []
      let confidence = 95

      if (foundKeywords.length > 0) {
        if (foundKeywords.includes("win") || foundKeywords.includes("congratulations")) {
          result = "suspicious"
          threats.push("Too good to be true offer")
          confidence = 85
        }
        if (messageText.includes("click here") || messageText.includes("bit.ly")) {
          result = "dangerous"
          threats.push("Suspicious link detected")
          confidence = 90
        }
        if (foundKeywords.includes("urgent") || foundKeywords.includes("account blocked")) {
          result = "dangerous"
          threats.push("Urgency tactics used")
          confidence = 88
        }
        if (foundKeywords.includes("otp") || foundKeywords.includes("pin")) {
          if (messageText.includes("share") || messageText.includes("call")) {
            result = "dangerous"
            threats.push("Asking for sensitive information")
            confidence = 92
          }
        }
      }

      setAnalysisResult({
        result,
        threats,
        confidence,
        message: messageText,
        timestamp: new Date().toLocaleString(),
      })
      setIsAnalyzing(false)
    }, 2000)
  }

  const getResultColor = (result: string) => {
    switch (result) {
      case "safe":
        return "text-green-600 bg-green-50 border-green-200"
      case "suspicious":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "dangerous":
        return "text-red-600 bg-red-50 border-red-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const getResultIcon = (result: string) => {
    switch (result) {
      case "safe":
        return <CheckCircle className="h-5 w-5" />
      case "suspicious":
        return <Eye className="h-5 w-5" />
      case "dangerous":
        return <AlertTriangle className="h-5 w-5" />
      default:
        return <Shield className="h-5 w-5" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="bg-purple-500 p-4 rounded-full">
              <MessageSquare className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-800">Message Checker</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Check if your SMS, WhatsApp, or email messages are safe or suspicious
          </p>
        </div>

        {/* Message Input */}
        <Card className="border-2 border-purple-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <Upload className="h-6 w-6 text-purple-600" />
              Check Your Message
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <label className="text-lg font-medium text-gray-700">Paste your message here:</label>
              <Textarea
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Copy and paste the suspicious message you received via SMS, WhatsApp, or email..."
                className="min-h-32 text-base resize-none"
              />
              <p className="text-sm text-gray-600">
                Your message is analyzed locally and securely. We don't store your personal information.
              </p>
            </div>

            <div className="flex gap-4">
              <Button
                onClick={handleAnalyzeMessage}
                disabled={!messageText.trim() || isAnalyzing}
                className="h-12 px-8 text-base font-medium bg-purple-600 hover:bg-purple-700"
              >
                {isAnalyzing ? "Analyzing..." : "Check Message"}
              </Button>
              <Button variant="outline" onClick={() => setMessageText("")} className="h-12 px-6 text-base">
                <Trash2 className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Analysis Result */}
        {analysisResult && (
          <Card className={`border-2 ${getResultColor(analysisResult.result)}`}>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                {getResultIcon(analysisResult.result)}
                Analysis Result
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold capitalize">{analysisResult.result}</h3>
                  <p className="text-gray-600">Confidence: {analysisResult.confidence}%</p>
                </div>
                <Badge
                  className={`text-lg px-4 py-2 ${
                    analysisResult.result === "safe"
                      ? "bg-green-500"
                      : analysisResult.result === "suspicious"
                        ? "bg-yellow-500"
                        : "bg-red-500"
                  }`}
                >
                  {analysisResult.result.toUpperCase()}
                </Badge>
              </div>

              {analysisResult.result === "safe" && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription className="text-base">
                    <strong>This message appears to be safe.</strong> No suspicious patterns detected. However, always
                    be cautious with personal information.
                  </AlertDescription>
                </Alert>
              )}

              {analysisResult.result === "suspicious" && (
                <Alert className="border-yellow-200 bg-yellow-50">
                  <Eye className="h-4 w-4" />
                  <AlertDescription className="text-base">
                    <strong>This message looks suspicious.</strong> Be very careful before taking any action. Consider
                    verifying through official channels.
                  </AlertDescription>
                </Alert>
              )}

              {analysisResult.result === "dangerous" && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-base">
                    <strong>This message is likely a scam!</strong> Do not click any links, share personal information,
                    or send money. Delete this message immediately.
                  </AlertDescription>
                </Alert>
              )}

              {analysisResult.threats.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-lg font-semibold text-gray-800">Detected Threats:</h4>
                  <div className="space-y-2">
                    {analysisResult.threats.map((threat: string, index: number) => (
                      <div key={index} className="flex items-center gap-3 p-3 bg-white rounded-lg border">
                        <AlertTriangle className="h-5 w-5 text-red-500" />
                        <span className="text-gray-700">{threat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-4 border-t">
                <h4 className="text-lg font-semibold text-gray-800 mb-3">What should you do?</h4>
                {analysisResult.result === "safe" && (
                  <ul className="space-y-2 text-gray-700">
                    <li>• The message appears legitimate, but stay vigilant</li>
                    <li>• Never share passwords or PINs, even if asked</li>
                    <li>• When in doubt, verify through official channels</li>
                  </ul>
                )}
                {analysisResult.result === "suspicious" && (
                  <ul className="space-y-2 text-gray-700">
                    <li>• Do not click any links in the message</li>
                    <li>• Verify the sender through official contact methods</li>
                    <li>• Ask a family member or friend for advice</li>
                    <li>• Report the message if confirmed as spam</li>
                  </ul>
                )}
                {analysisResult.result === "dangerous" && (
                  <ul className="space-y-2 text-gray-700">
                    <li>
                      • <strong>Delete the message immediately</strong>
                    </li>
                    <li>• Do not click any links or call any numbers</li>
                    <li>• Block the sender's number</li>
                    <li>• Report to cybercrime helpline (1930)</li>
                    <li>• Warn your family and friends about this scam</li>
                  </ul>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Checks */}
        <Card className="border-2 border-gray-200">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-3">
              <History className="h-6 w-6 text-gray-600" />
              Recent Checks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentChecks.map((check) => (
                <div key={check.id} className={`p-4 rounded-lg border-2 ${getResultColor(check.result)}`}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {getResultIcon(check.result)}
                      <Badge
                        className={`${
                          check.result === "safe"
                            ? "bg-green-500"
                            : check.result === "suspicious"
                              ? "bg-yellow-500"
                              : "bg-red-500"
                        }`}
                      >
                        {check.result.toUpperCase()}
                      </Badge>
                    </div>
                    <span className="text-sm text-gray-500">{check.timestamp}</span>
                  </div>

                  <p className="text-gray-700 mb-3 p-3 bg-white rounded border">"{check.message}"</p>

                  {check.threats.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-700">Threats detected:</p>
                      <div className="flex flex-wrap gap-2">
                        {check.threats.map((threat, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {threat}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tips */}
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-xl">Message Safety Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-bold text-gray-800">🚨 Red Flags to Watch For:</h4>
                <ul className="space-y-2 text-gray-700">
                  <li>• Urgent action required immediately</li>
                  <li>• Too good to be true offers</li>
                  <li>• Requests for OTP, PIN, or passwords</li>
                  <li>• Suspicious links (bit.ly, tinyurl, etc.)</li>
                  <li>• Poor grammar and spelling</li>
                </ul>
              </div>
              <div className="space-y-3">
                <h4 className="font-bold text-gray-800">✅ Safety Best Practices:</h4>
                <ul className="space-y-2 text-gray-700">
                  <li>• Always verify sender identity</li>
                  <li>• Check messages using this tool</li>
                  <li>• Never share sensitive information</li>
                  <li>• Contact official customer service</li>
                  <li>• Trust your instincts</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
