"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, User, Mail, Lock, Globe, Phone, Eye, EyeOff, MapPin, Sparkles } from "lucide-react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    location: "",
    state: "",
    language: "english",
    emergencyContact: "",
    emergencyName: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const router = useRouter()

  const indianStates = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Delhi",
    "Jammu and Kashmir",
    "Ladakh",
  ]

  const languages = [
    { value: "english", label: "English", flag: "🇺🇸" },
    { value: "hindi", label: "हिंदी (Hindi)", flag: "🇮🇳" },
    { value: "tamil", label: "தமிழ் (Tamil)", flag: "🇮🇳" },
    { value: "telugu", label: "తెలుగు (Telugu)", flag: "🇮🇳" },
    { value: "malayalam", label: "മലയാളം (Malayalam)", flag: "🇮🇳" },
    { value: "kannada", label: "ಕನ್ನಡ (Kannada)", flag: "🇮🇳" },
    { value: "bengali", label: "বাংলা (Bengali)", flag: "🇮🇳" },
    { value: "gujarati", label: "ગુજરાતી (Gujarati)", flag: "🇮🇳" },
    { value: "marathi", label: "मराठी (Marathi)", flag: "🇮🇳" },
    { value: "punjabi", label: "ਪੰਜਾਬੀ (Punjabi)", flag: "🇮🇳" },
  ]

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.email) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address"
    }

    if (!formData.password) {
      newErrors.password = "Password is required"
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters"
    }

    if (!isLogin) {
      if (!formData.name) newErrors.name = "Name is required"
      if (!formData.phone) newErrors.phone = "Phone number is required"
      if (!formData.location) newErrors.location = "City is required"
      if (!formData.state) newErrors.state = "State is required"
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = "Passwords do not match"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validateForm()) return

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Store user data in localStorage (in real app, this would be sent to backend)
    if (!isLogin) {
      localStorage.setItem(
        "userData",
        JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          location: `${formData.location}, ${formData.state}`,
          language: formData.language,
          emergencyContact: formData.emergencyContact,
          emergencyName: formData.emergencyName,
          joinDate: new Date().toISOString(),
        }),
      )
    }

    setIsLoading(false)
    router.push("/")
  }

  // Floating animation for background elements
  useEffect(() => {
    const elements = document.querySelectorAll(".floating-element")
    elements.forEach((el, index) => {
      const element = el as HTMLElement
      element.style.animationDelay = `${index * 0.5}s`
    })
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-100 via-sky-50 to-emerald-100 relative overflow-hidden">
      {/* Enhanced Background Pattern */}
      <div className="absolute inset-0">
        {/* Animated floating elements */}
        <div className="floating-element absolute top-20 left-20 w-32 h-32 bg-gradient-to-br from-blue-400/30 to-cyan-400/30 rounded-full blur-xl animate-bounce"></div>
        <div className="floating-element absolute top-40 right-32 w-24 h-24 bg-gradient-to-br from-purple-400/30 to-pink-400/30 rounded-full blur-lg animate-pulse"></div>
        <div className="floating-element absolute bottom-32 left-1/4 w-40 h-40 bg-gradient-to-br from-indigo-400/30 to-blue-400/30 rounded-full blur-2xl animate-ping"></div>
        <div className="floating-element absolute bottom-60 right-20 w-28 h-28 bg-gradient-to-br from-emerald-400/30 to-teal-400/30 rounded-full blur-lg animate-bounce"></div>

        {/* Geometric shapes */}
        <div className="absolute top-1/4 left-10 w-16 h-16 border-4 border-blue-300/40 rotate-45 animate-spin"></div>
        <div className="absolute bottom-1/4 right-10 w-20 h-20 border-4 border-purple-300/40 rounded-full animate-pulse"></div>

        {/* Gradient mesh overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen p-6">
        <Card className="w-full max-w-lg border-0 shadow-2xl bg-white/80 backdrop-blur-xl rounded-3xl overflow-hidden">
          {/* Animated Header */}
          <CardHeader className="text-center space-y-6 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 text-white rounded-t-3xl relative overflow-hidden">
            {/* Header background animation */}
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 via-purple-600/90 to-indigo-600/90"></div>
            <div className="absolute inset-0">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/10 to-transparent animate-pulse"></div>
            </div>

            <div className="relative z-10 flex items-center justify-center gap-4">
              <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl shadow-lg border border-white/30 animate-pulse">
                <Shield className="h-10 w-10 text-white" />
              </div>
              <div>
                <CardTitle className="text-3xl font-bold flex items-center gap-2">
                  CyberSafe
                  <Sparkles className="h-6 w-6 text-yellow-300 animate-spin" />
                </CardTitle>
                <p className="text-blue-100 text-lg">Digital Security for Seniors</p>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-8 space-y-6">
            {/* Dynamic Title */}
            <div className="text-center space-y-3">
              <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {isLogin ? "Welcome Back!" : "Join Our Community"}
              </h2>
              <p className="text-gray-600 text-lg">
                {isLogin ? "Sign in to continue your cyber safety journey" : "Create your account to start learning"}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {!isLogin && (
                <>
                  {/* Name Field */}
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-base font-semibold flex items-center gap-2 text-gray-700">
                      <User className="h-5 w-5 text-blue-600" />
                      Full Name *
                    </Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`h-14 text-base rounded-xl border-2 transition-all duration-300 ${
                        errors.name
                          ? "border-red-400 bg-red-50"
                          : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                      }`}
                      required={!isLogin}
                    />
                    {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
                  </div>

                  {/* Phone Field */}
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-base font-semibold flex items-center gap-2 text-gray-700">
                      <Phone className="h-5 w-5 text-blue-600" />
                      Phone Number *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+91 98765 43210"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className={`h-14 text-base rounded-xl border-2 transition-all duration-300 ${
                        errors.phone
                          ? "border-red-400 bg-red-50"
                          : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                      }`}
                      required={!isLogin}
                    />
                    {errors.phone && <p className="text-red-500 text-sm">{errors.phone}</p>}
                  </div>

                  {/* Location Fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label
                        htmlFor="location"
                        className="text-base font-semibold flex items-center gap-2 text-gray-700"
                      >
                        <MapPin className="h-5 w-5 text-blue-600" />
                        City *
                      </Label>
                      <Input
                        id="location"
                        type="text"
                        placeholder="Your city"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                        className={`h-14 text-base rounded-xl border-2 transition-all duration-300 ${
                          errors.location
                            ? "border-red-400 bg-red-50"
                            : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                        }`}
                        required={!isLogin}
                      />
                      {errors.location && <p className="text-red-500 text-sm">{errors.location}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="state" className="text-base font-semibold flex items-center gap-2 text-gray-700">
                        <Globe className="h-5 w-5 text-blue-600" />
                        State *
                      </Label>
                      <Select
                        value={formData.state}
                        onValueChange={(value) => setFormData({ ...formData, state: value })}
                      >
                        <SelectTrigger
                          className={`h-14 text-base rounded-xl border-2 transition-all duration-300 ${
                            errors.state ? "border-red-400 bg-red-50" : "border-gray-200 focus:border-blue-400"
                          }`}
                        >
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          {indianStates.map((state) => (
                            <SelectItem key={state} value={state} className="text-base py-3">
                              {state}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.state && <p className="text-red-500 text-sm">{errors.state}</p>}
                    </div>
                  </div>
                </>
              )}

              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-base font-semibold flex items-center gap-2 text-gray-700">
                  <Mail className="h-5 w-5 text-blue-600" />
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`h-14 text-base rounded-xl border-2 transition-all duration-300 ${
                    errors.email ? "border-red-400 bg-red-50" : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                  }`}
                  required
                />
                {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-base font-semibold flex items-center gap-2 text-gray-700">
                  <Lock className="h-5 w-5 text-blue-600" />
                  Password *
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={`h-14 text-base rounded-xl border-2 pr-14 transition-all duration-300 ${
                      errors.password
                        ? "border-red-400 bg-red-50"
                        : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                    }`}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-3 top-1/2 -translate-y-1/2 hover:bg-blue-100"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5 text-gray-500" />
                    ) : (
                      <Eye className="h-5 w-5 text-gray-500" />
                    )}
                  </Button>
                </div>
                {errors.password && <p className="text-red-500 text-sm">{errors.password}</p>}
              </div>

              {!isLogin && (
                <>
                  {/* Confirm Password */}
                  <div className="space-y-2">
                    <Label
                      htmlFor="confirmPassword"
                      className="text-base font-semibold flex items-center gap-2 text-gray-700"
                    >
                      <Lock className="h-5 w-5 text-blue-600" />
                      Confirm Password *
                    </Label>
                    <Input
                      id="confirmPassword"
                      type={showPassword ? "text" : "password"}
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      className={`h-14 text-base rounded-xl border-2 transition-all duration-300 ${
                        errors.confirmPassword
                          ? "border-red-400 bg-red-50"
                          : "border-gray-200 focus:border-blue-400 focus:bg-blue-50"
                      }`}
                      required
                    />
                    {errors.confirmPassword && <p className="text-red-500 text-sm">{errors.confirmPassword}</p>}
                  </div>

                  {/* Language Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="language" className="text-base font-semibold flex items-center gap-2 text-gray-700">
                      <Globe className="h-5 w-5 text-blue-600" />
                      Preferred Language
                    </Label>
                    <Select
                      value={formData.language}
                      onValueChange={(value) => setFormData({ ...formData, language: value })}
                    >
                      <SelectTrigger className="h-14 text-base rounded-xl border-2 border-gray-200 focus:border-blue-400">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {languages.map((lang) => (
                          <SelectItem key={lang.value} value={lang.value} className="text-base py-3">
                            <div className="flex items-center gap-3">
                              <span className="text-xl">{lang.flag}</span>
                              <span>{lang.label}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Emergency Contact */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label
                        htmlFor="emergencyName"
                        className="text-base font-semibold flex items-center gap-2 text-gray-700"
                      >
                        <User className="h-5 w-5 text-blue-600" />
                        Emergency Contact Name
                      </Label>
                      <Input
                        id="emergencyName"
                        type="text"
                        placeholder="Family member name"
                        value={formData.emergencyName}
                        onChange={(e) => setFormData({ ...formData, emergencyName: e.target.value })}
                        className="h-14 text-base rounded-xl border-2 border-gray-200 focus:border-blue-400 focus:bg-blue-50 transition-all duration-300"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label
                        htmlFor="emergencyContact"
                        className="text-base font-semibold flex items-center gap-2 text-gray-700"
                      >
                        <Phone className="h-5 w-5 text-blue-600" />
                        Emergency Phone
                      </Label>
                      <Input
                        id="emergencyContact"
                        type="tel"
                        placeholder="+91 98765 43210"
                        value={formData.emergencyContact}
                        onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                        className="h-14 text-base rounded-xl border-2 border-gray-200 focus:border-blue-400 focus:bg-blue-50 transition-all duration-300"
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-16 text-xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-700 rounded-xl shadow-lg transform transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
                    {isLogin ? "Signing In..." : "Creating Account..."}
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    {isLogin ? "Sign In" : "Create Account"}
                    <Sparkles className="h-5 w-5" />
                  </div>
                )}
              </Button>
            </form>

            {/* Toggle Login/Signup */}
            <div className="text-center space-y-4">
              <p className="text-gray-600 text-lg">{isLogin ? "Don't have an account?" : "Already have an account?"}</p>
              <Button
                variant="outline"
                onClick={() => {
                  setIsLogin(!isLogin)
                  setErrors({})
                  setFormData({
                    name: "",
                    email: "",
                    password: "",
                    confirmPassword: "",
                    phone: "",
                    location: "",
                    state: "",
                    language: "english",
                    emergencyContact: "",
                    emergencyName: "",
                  })
                }}
                className="w-full h-14 text-lg border-2 border-blue-200 hover:bg-blue-50 hover:border-blue-400 rounded-xl transition-all duration-300"
              >
                {isLogin ? "Create New Account" : "Sign In Instead"}
              </Button>
            </div>

            {!isLogin && (
              <div className="text-center text-sm text-gray-500 space-y-3 bg-gray-50 rounded-xl p-4">
                <p className="font-medium">By creating an account, you agree to our</p>
                <div className="flex justify-center gap-4">
                  <button className="text-blue-600 hover:underline font-medium">Terms of Service</button>
                  <span>•</span>
                  <button className="text-blue-600 hover:underline font-medium">Privacy Policy</button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
