"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Shield,
  BookOpen,
  HelpCircle,
  Bell,
  Phone,
  Sun,
  MessageSquare,
  MapPin,
  UserIcon,
  Calendar,
  Users,
  BarChart3,
  Settings,
  LogOut,
} from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { getCurrentUser, getUserDashboardConfig, logout } from "@/lib/auth"
import { AuthGuard } from "@/components/auth-guard"

function HomePage() {
  const [greeting, setGreeting] = useState("")
  const [currentTime, setCurrentTime] = useState("")
  const [currentUser, setCurrentUser] = useState<any | null>(null)
  const [dashboardConfig, setDashboardConfig] = useState<any>(null)

  useEffect(() => {
    const user = getCurrentUser()
    if (user) {
      setCurrentUser(user)
      setDashboardConfig(getUserDashboardConfig(user.userType))
    }

    const updateTime = () => {
      const now = new Date()
      const hour = now.getHours()
      const timeString = now.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      })

      setCurrentTime(timeString)

      if (hour < 12) {
        setGreeting("Good Morning")
      } else if (hour < 17) {
        setGreeting("Good Afternoon")
      } else {
        setGreeting("Good Evening")
      }
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  // User-type specific quick actions
  const getQuickActions = () => {
    if (!currentUser || !dashboardConfig) return []

    const baseActions = {
      senior: [
        {
          title: "Start Learning",
          description: "Begin your cyber safety journey",
          icon: BookOpen,
          href: "/learn",
          color: "bg-gradient-to-br from-emerald-500 via-green-500 to-teal-600",
        },
        {
          title: "Take Quiz",
          description: "Test your knowledge",
          icon: HelpCircle,
          href: "/quiz",
          color: "bg-gradient-to-br from-blue-500 via-cyan-500 to-indigo-600",
        },
        {
          title: "Emergency Help",
          description: "Get immediate assistance",
          icon: Phone,
          href: "/emergency",
          color: "bg-gradient-to-br from-red-500 via-rose-500 to-pink-600",
        },
        {
          title: "Check Message",
          description: "Verify suspicious messages",
          icon: MessageSquare,
          href: "/checker",
          color: "bg-gradient-to-br from-purple-500 via-violet-500 to-indigo-600",
        },
      ],
      family: [
        {
          title: "Monitor Progress",
          description: "Track family member's learning",
          icon: BarChart3,
          href: "/monitor",
          color: "bg-gradient-to-br from-green-500 via-emerald-500 to-teal-600",
        },
        {
          title: "Safety Alerts",
          description: "View recent security alerts",
          icon: Bell,
          href: "/alerts",
          color: "bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-600",
        },
        {
          title: "Learning Resources",
          description: "Access educational materials",
          icon: BookOpen,
          href: "/learn",
          color: "bg-gradient-to-br from-blue-500 via-cyan-500 to-indigo-600",
        },
        {
          title: "Emergency Contacts",
          description: "Manage emergency contacts",
          icon: Phone,
          href: "/emergency",
          color: "bg-gradient-to-br from-red-500 via-rose-500 to-pink-600",
        },
      ],
      caregiver: [
        {
          title: "Manage Users",
          description: "Oversee multiple senior accounts",
          icon: Users,
          href: "/manage",
          color: "bg-gradient-to-br from-purple-500 via-violet-500 to-indigo-600",
        },
        {
          title: "Training Reports",
          description: "View detailed progress reports",
          icon: BarChart3,
          href: "/reports",
          color: "bg-gradient-to-br from-blue-500 via-cyan-500 to-indigo-600",
        },
        {
          title: "Safety Training",
          description: "Access professional resources",
          icon: Shield,
          href: "/training",
          color: "bg-gradient-to-br from-green-500 via-emerald-500 to-teal-600",
        },
        {
          title: "Alert System",
          description: "Monitor security incidents",
          icon: Bell,
          href: "/alerts",
          color: "bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-600",
        },
      ],
    }

    return baseActions[currentUser.userType] || baseActions.senior
  }

  const getUserTypeLabel = (userType: string) => {
    const labels = {
      senior: "Senior Citizen",
      family: "Family Member",
      caregiver: "Professional Caregiver",
    }
    return labels[userType as keyof typeof labels] || "User"
  }

  const getUserTypeColor = (userType: string) => {
    const colors = {
      senior: "bg-blue-100 text-blue-800 border-blue-200",
      family: "bg-green-100 text-green-800 border-green-200",
      caregiver: "bg-purple-100 text-purple-800 border-purple-200",
    }
    return colors[userType as keyof typeof colors] || colors.senior
  }

  if (!currentUser) {
    return null
  }

  const quickActions = getQuickActions()
  const userName = currentUser.name.split(" ")[0]

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-100 via-sky-50 to-emerald-100 relative overflow-hidden">
      {/* Enhanced Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-br from-blue-400/20 via-cyan-400/20 to-emerald-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-60 right-32 w-80 h-80 bg-gradient-to-br from-purple-400/20 via-pink-400/20 to-rose-400/20 rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-32 left-1/3 w-72 h-72 bg-gradient-to-br from-indigo-400/20 via-blue-400/20 to-cyan-400/20 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      <div className="relative z-10 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Enhanced Welcome Header with User Type */}
          <div className="text-center space-y-6">
            <div className="flex flex-col lg:flex-row items-center justify-center gap-6">
              <div className="bg-white/90 backdrop-blur-xl p-6 rounded-3xl shadow-2xl border border-blue-200/50">
                <Shield className="h-16 w-16 text-blue-600 animate-pulse" />
              </div>
              <div className="bg-white/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-blue-200/50 text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start gap-3 mb-2">
                  <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
                    {greeting}, {userName}!
                  </h1>
                  <Badge className={`text-sm px-3 py-1 border-2 ${getUserTypeColor(currentUser.userType)}`}>
                    {getUserTypeLabel(currentUser.userType)}
                  </Badge>
                </div>
                <div className="flex items-center justify-center lg:justify-start gap-4 mt-3">
                  <p className="text-2xl text-gray-600">{currentTime}</p>
                  <div className="flex items-center gap-2 text-lg text-gray-500">
                    <Sun className="h-5 w-5 text-yellow-500" />
                    24°C • Sunny
                  </div>
                </div>
                <div className="flex items-center justify-center lg:justify-start gap-4 mt-2 text-gray-500">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>
                      {currentUser.city}, {currentUser.state}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>Member since {new Date(currentUser.joinDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              {/* User Actions */}
              <div className="flex flex-col gap-3">
                <Link href="/profile">
                  <Button variant="outline" className="bg-white/80 hover:bg-white border-2 border-blue-200">
                    <UserIcon className="h-4 w-4 mr-2" />
                    Profile
                  </Button>
                </Link>
                <Link href="/settings">
                  <Button variant="outline" className="bg-white/80 hover:bg-white border-2 border-gray-200">
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  onClick={logout}
                  className="bg-white/80 hover:bg-red-50 border-2 border-red-200 text-red-600 hover:text-red-700"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </div>
          </div>

          {/* User-Type Specific Welcome Message */}
          <Card className="border-2 border-yellow-300 bg-gradient-to-r from-yellow-50 via-orange-50 to-amber-50 shadow-2xl backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="text-center">
                {currentUser.userType === "senior" && (
                  <p className="text-xl text-gray-700 font-medium">
                    🛡️ Welcome to your personal cyber safety dashboard. Learn at your own pace and stay protected online
                    with our easy-to-follow lessons.
                  </p>
                )}
                {currentUser.userType === "family" && (
                  <p className="text-xl text-gray-700 font-medium">
                    👨‍👩‍👧‍👦 Help keep your elderly family members safe online. Monitor their progress and stay informed
                    about potential threats in your area.
                  </p>
                )}
                {currentUser.userType === "caregiver" && (
                  <p className="text-xl text-gray-700 font-medium">
                    👩‍⚕️ Manage and monitor multiple senior accounts. Access professional resources and detailed reports
                    to provide the best care.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* User-Type Specific Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {quickActions.map((action, index) => (
              <Link key={index} href={action.href}>
                <Card className="h-full hover:shadow-2xl transition-all duration-500 cursor-pointer border-2 hover:border-blue-300 bg-white/90 backdrop-blur-xl hover:scale-110 transform group">
                  <CardContent className="p-8 text-center space-y-6">
                    <div
                      className={`${action.color} p-6 rounded-2xl w-20 h-20 mx-auto flex items-center justify-center shadow-xl transform group-hover:rotate-12 transition-all duration-500`}
                    >
                      <action.icon className="h-10 w-10 text-white" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-800 group-hover:text-blue-600 transition-colors">
                        {action.title}
                      </h3>
                      <p className="text-gray-600 mt-3 text-lg">{action.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* User Profile Summary */}
          <Card className="border-2 border-purple-200 bg-gradient-to-r from-purple-50 via-violet-50 to-indigo-50 shadow-2xl backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <div className="bg-gradient-to-br from-purple-500 to-indigo-600 p-3 rounded-2xl">
                  <UserIcon className="h-8 w-8 text-white" />
                </div>
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/50">
                  <h4 className="font-semibold text-gray-800 mb-2">Contact Info</h4>
                  <p className="text-gray-600">{currentUser.email}</p>
                  <p className="text-gray-600">{currentUser.phone}</p>
                </div>
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/50">
                  <h4 className="font-semibold text-gray-800 mb-2">Location</h4>
                  <p className="text-gray-600">{currentUser.address}</p>
                  <p className="text-gray-600">
                    {currentUser.city}, {currentUser.state}
                  </p>
                </div>
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/50">
                  <h4 className="font-semibold text-gray-800 mb-2">Account Type</h4>
                  <Badge className={`${getUserTypeColor(currentUser.userType)} text-sm`}>
                    {getUserTypeLabel(currentUser.userType)}
                  </Badge>
                </div>
                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/50">
                  <h4 className="font-semibold text-gray-800 mb-2">Status</h4>
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    {currentUser.isVerified ? "Verified" : "Pending"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default function Page() {
  return (
    <AuthGuard>
      <HomePage />
    </AuthGuard>
  )
}
